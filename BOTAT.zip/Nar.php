<?php
/*
تم نشر ملف بوت المصنع بسبب هذا الفرخ @xxi10 روحو لعنده قولوله كسمك
                         _
 ___  __ _  ___  ___  __| |
/ __|/ _` |/ _ \/ _ \/ _` |
\__ \ (_| |  __/  __/ (_| |
|___/\__,_|\___|\___|\__,_|
 _____
|_____|
     _
  __| | _____   __
 / _` |/ _ \ \ / /
| (_| |  __/\ V /
 \__,_|\___| \_/
 
 
 */
 
 $get_toke = file_get_contents('info.txt');

$get_token = explode("\n", $get_toke);

ob_start();
$API_KEY = $get_token[0];
define('API_KEY', $API_KEY);
echo "https://api.telegram.org/bot" . API_KEY . "/setwebhook?url=" . $_SERVER['SERVER_NAME'] . "" . $_SERVER['SCRIPT_NAME'];

function bot($method, $datas = [])
  {
  $url = "https://api.telegram.org/bot" . API_KEY . "/" . $method;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
  $res = curl_exec($ch);
  if (curl_error($ch))
    {
    var_dump(curl_error($ch));
    }
    else
    {
    return json_decode($res);
    }
  }

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$text = $message->text;
$chat_id2 = $update->callback_query->message->chat->id;
$message_id = $update->callback_query->message->message_id;
$data = $update->callback_query->data;
$from_id = $message->from->id;
$name = $update->message->from->first_name;
$sudo = $get_token[1];
$from_id = $message->from->id;
$join = bot('getChatMember', ["chat_id" => "@TM_SAEED", "user_id" => $from_id])->result->status;

if ($message && $join == 'left')
  {
  bot('sendMessage', ['chat_id' => $chat_id, 'text' => "- عليك الاشتراك في القناة ليتم تشغيل البوت .'🚫", 'reply_markup' => json_encode(['inline_keyboard' => [[['text' => '• اشترك -🔱 ', 'url' => 'https://t.me/TM_SAEED']]]]) ]);
  die('مشيولي');
  }

$ex = explode(' ', $text);

if ($text == '/start')
  {
  bot('sendMessage', ['chat_id' => $chat_id, 'text' => "`- مرحبا بك يا `[$name](tg://user?id=$chat_id) `في بوت الكتابة بالنار 🔥`

 `- قم بأرسال اسمك وانتظر اسال الصورة اليك ؛ 📸`", 'parse_mode' => "MarkDown", 'disable_web_page_preview' => true, 'reply_markup' => json_encode(['inline_keyboard' => [[['text'=>"📡 - تابع جديدنا - 📡",'url'=>'https://t.me/joinchat/AAAAAEvja9x5FT8SMUSMaA']],
[['text'=>"🔧 - اصنع بوتك الخاص - 🔧",'url'=>'t.me/DS_DS18BOT']],
 ]]) ]);
  }
  
$f = explode("\n", file_get_contents("usersaeed.txt"));
        if ($update and !in_array($chat_id, $f)) {
            file_put_contents("usersaeed.txt", $chat_id."\n",FILE_APPEND);
        } 
        if ($text == "المشتركين" and $chat_id == $sudo) {
            bot("sendMessage",[
                "chat_id"=>$chat_id,
                "text"=>count($f)
            ]);
        }

if (preg_match("/\/bc .*/", $text) and $chat_id == $sudo) {
            $f = explode("\n", file_get_contents("usersaeed.txt"));
            $text = str_replace("/bc ", "", $text);
            for ($i=0; $i < count($f); $i++) { 
                bot("sendMessage",[
                    "chat_id"=>$f[$i],
                    "text"=>$text
                ]);
            }
        }
if ($text != '/start')
  {
      if(preg_match('/[a-z]/i',$text)){
    $str = str_split(strtolower($text));
  foreach($str as $char){
    $im[] = 'https://sajad.gq/w/p/'.$char.'.jpg';
}
if(count($str) == 1){
    file_put_contents($chat_id.'.jpg',file_get_contents($im[0]));
    $data = getimagesize("$chat_id.jpg");
    $dest = imagecreatefromjpeg("$chat_id.jpg");
  $src = imagecreatetruecolor($data[0] + 250,$data[1]);
  imagefill($src, 0, 0, imagecolorallocate($src,255,255,255));
  imagecopy($src, $dest, 125, 0, 0, 0 ,$data[0] , $data[1]);
  imagejpeg($src,$chat_id.'1.jpg');
  imagedestroy($src);
  imagedestroy($dest);
    bot('sendPhoto',[
      'chat_id'=>$chat_id,
      'photo'=>new CURLFile($chat_id.'.jpg')
    ]);
    bot('sendPhoto',[
      'chat_id'=>$chat_id,
      'photo'=>new CURLFile($chat_id.'1.jpg')
    ]);
} elseif(count($str) == 2){
    $img = imagecreatetruecolor(1300, 740);
    imagefill($img, 0, 0, imagecolorallocate($img,255,255,255));
    $cur = imagecreatefromjpeg($im[0]);
    imagecopy($img, $cur, 10, 0, 0, 0, 640, 740);
    imagedestroy($cur);
    
    imagepng($img,'1.png');
    $img1 = imagecreatefrompng('1.png');
    $cur1 = imagecreatefromjpeg($im[1]);
    imagecopy($img1, $cur1, 650, 0, 0, 0, 640, 740);
    imagepng($img1,$chat_id.'.jpg');
    bot('sendPhoto',[
      'chat_id'=>$chat_id,
      'photo'=>new CURLFile($chat_id.'.jpg')
    ]);
}
if(count($str) == 3){
    $img = imagecreatetruecolor(1920, 740);
    $cur = imagecreatefromjpeg($im[0]);
    imagecopy($img, $cur, 0, 0, 0, 0, 640, 740);
    imagedestroy($cur);
    imagepng($img,'1.png');
    $img1 = imagecreatefrompng('1.png');
    $cur1 = imagecreatefromjpeg($im[1]);
    imagecopy($img1, $cur1, 640, 0, 0, 0, 640, 740);
    imagepng($img1,'2.png');
    $img2 = imagecreatefrompng('2.png');
    $cur2 = imagecreatefromjpeg($im[2]);
    imagecopy($img2, $cur2, 740, 0, 0, 0, 640, 740);
    imagepng($img2,$chat_id.'.jpg');
    unlink('1.png');
    unlink('2.png');
    $dest = imagecreatefrompng($chat_id.".jpg");
    $src = imagecreatetruecolor(1920,1920);
    imagefill($src, 0, 0, imagecolorallocate($src,255,255,255));
    imagecopy($src, $dest, 0, 600, 0, 0 ,1920 , 740);
    imagejpeg($src,$chat_id.'1.jpg');
    imagedestroy($src);
    imagedestroy($dest);
    bot('sendPhoto',[
      'chat_id'=>$chat_id,
      'photo'=>new CURLFile($chat_id.'.jpg')
    ]);
    bot('sendPhoto',[
      'chat_id'=>$chat_id,
      'photo'=>new CURLFile($chat_id.'1.jpg')
    ]);
} elseif(count($str) == 4){
    $img = imagecreatetruecolor(2560, 740);imagefill($img, 0, 0, imagecolorallocate($img,255,255,255));
    $cur = imagecreatefromjpeg($im[0]);
    imagecopy($img, $cur, 20, 0, 0, 0, 640, 740);
    imagedestroy($cur);
    imagepng($img,'1.png');
    $img1 = imagecreatefrompng('1.png');
    $cur1 = imagecreatefromjpeg($im[1]);
    imagecopy($img1, $cur1, 640, 0, 0, 0, 640, 740);
    imagepng($img1,'2.png');
    $img2 = imagecreatefrompng('2.png');
    $cur2 = imagecreatefromjpeg($im[2]);
    imagecopy($img2, $cur2, 1260, 0, 0, 0, 640, 740);
    imagepng($img2,'3.png');
    $img3 = imagecreatefrompng('3.png');
    $cur3 = imagecreatefromjpeg($im[3]);
    imagecopy($img3, $cur3, 1880, 0, 0, 0, 640, 740);
    $imm3 = imagecrop($img3, ['x' => 20, 'y' => 20, 'width' => 2560, 'height' => 740]);
    imagepng($img3,$chat_id.'.jpg');
    unlink('1.png');
    unlink('2.png');
    unlink('3.png');
    $dest = imagecreatefrompng($chat_id.'.jpg');
    $src = imagecreatetruecolor(2560,2560);
    imagefill($src, 0, 0, imagecolorallocate($src,255,255,255));
    imagecopy($src, $dest, 0, 900, 0, 0 ,2560 , 740);
    imagejpeg($src,$chat_id.'1.jpg');
    imagedestroy($src);
    imagedestroy($dest);
    bot('sendPhoto',[
      'chat_id'=>$chat_id,
      'photo'=>new CURLFile($chat_id.'.jpg')
    ]);
    bot('sendPhoto',[
      'chat_id'=>$chat_id,
      'photo'=>new CURLFile($chat_id.'1.jpg')
    ]);
} elseif(count($str) == 5){
    $img = imagecreatetruecolor(3200, 740);imagefill($img, 0, 0, imagecolorallocate($img,255,255,255));
    $cur = imagecreatefromjpeg($im[0]);
    imagecopy($img, $cur, 20, 0, 0, 0, 640, 740);
    imagedestroy($cur);
    imagepng($img,'1.png');
    $img1 = imagecreatefrompng('1.png');
    $cur1 = imagecreatefromjpeg($im[1]);
    imagecopy($img1, $cur1, 640, 0, 0, 0, 640, 740);
    imagepng($img1,'2.png');
    $img2 = imagecreatefrompng('2.png');
    $cur2 = imagecreatefromjpeg($im[2]);
    imagecopy($img2, $cur2, 1260, 0, 0, 0, 640, 740);
    imagepng($img2,'3.png');
    $img3 = imagecreatefrompng('3.png');
    $cur3 = imagecreatefromjpeg($im[3]);
    imagecopy($img3, $cur3, 1880, 0, 0, 0, 640, 740);
    imagepng($img3,'4.png');
    $img4 = imagecreatefrompng('4.png');
    $cur4 = imagecreatefromjpeg($im[4]);
    imagecopy($img4, $cur4, 2520, 0, 0, 0, 640, 740);
    imagepng($img4,$chat_id.'.jpg');
    unlink('1.png');
    unlink('2.png');
    unlink('3.png');
    unlink('4.png');
    $dest = imagecreatefrompng($chat_id.".jpg");
    $src = imagecreatetruecolor(3200,3200);
    imagefill($src, 0, 0, imagecolorallocate($src,255,255,255));
    imagecopy($src, $dest, 0, 1200, 0, 0 ,3200 , 740);
    imagejpeg($src,$chat_id.'1.jpg');
    imagedestroy($src);
    imagedestroy($dest);
    bot('sendPhoto',[
      'chat_id'=>$chat_id,
      'photo'=>new CURLFile($chat_id.'.jpg')
    ]);
    bot('sendPhoto',[
      'chat_id'=>$chat_id,
      'photo'=>new CURLFile($chat_id.'1.jpg')
    ]);
} elseif(count($str) == 6){
    $img = imagecreatetruecolor(3840, 740);imagefill($img, 0, 0, imagecolorallocate($img,255,255,255));
    $cur = imagecreatefromjpeg($im[0]);
    imagecopy($img, $cur, 20, 0, 0, 0, 640, 740);
    imagedestroy($cur);
    imagepng($img,'1.png');
    $img1 = imagecreatefrompng('1.png');
    $cur1 = imagecreatefromjpeg($im[1]);
    imagecopy($img1, $cur1, 640, 0, 0, 0, 640, 740);
    imagepng($img1,'2.png');
    $img2 = imagecreatefrompng('2.png');
    $cur2 = imagecreatefromjpeg($im[2]);
    imagecopy($img2, $cur2, 1260, 0, 0, 0, 640, 740);
    imagepng($img2,'3.png');
    $img3 = imagecreatefrompng('3.png');
    $cur3 = imagecreatefromjpeg($im[3]);
    imagecopy($img3, $cur3, 1880, 0, 0, 0, 640, 740);
    imagepng($img3,'4.png');
    $img4 = imagecreatefrompng('4.png');
    $cur4 = imagecreatefromjpeg($im[4]);
    imagecopy($img4, $cur4, 2520, 0, 0, 0, 640, 740);
    imagepng($img4,'5.png');
    $img5 = imagecreatefrompng('5.png');
    $cur5 = imagecreatefromjpeg($im[5]);
    imagecopy($img5, $cur5, 3160, 0, 0, 0, 640, 740);
    imagepng($img5,$chat_id.'.jpg');
    unlink('1.png');
    unlink('2.png');
    unlink('3.png');
    unlink('4.png');
    unlink('5.png');
    $dest = imagecreatefrompng($chat_id.".jpg");
    $src = imagecreatetruecolor(3840,3840);
    imagefill($src, 0, 0, imagecolorallocate($src,255,255,255));
    imagecopy($src, $dest, 0, 1500, 0, 0 ,3840 , 740);
    imagejpeg($src,$chat_id.'1.jpg');
    imagedestroy($src);
    imagedestroy($dest);
    bot('sendPhoto',[
      'chat_id'=>$chat_id,
      'photo'=>new CURLFile($chat_id.'.jpg')
    ]);
    bot('sendPhoto',[
      'chat_id'=>$chat_id,
      'photo'=>new CURLFile($chat_id.'1.jpg')
    ]);
} elseif(count($str) == 7){
    $img = imagecreatetruecolor(4480, 740);imagefill($img, 0, 0, imagecolorallocate($img,255,255,255));
    $cur = imagecreatefromjpeg($im[0]);
    imagecopy($img, $cur, 20, 0, 0, 0, 640, 740);
    imagedestroy($cur);
    imagepng($img,'1.png');
    $img1 = imagecreatefrompng('1.png');
    $cur1 = imagecreatefromjpeg($im[1]);
    imagecopy($img1, $cur1, 640, 0, 0, 0, 640, 740);
    imagepng($img1,'2.png');
    $img2 = imagecreatefrompng('2.png');
    $cur2 = imagecreatefromjpeg($im[2]);
    imagecopy($img2, $cur2, 1260, 0, 0, 0, 640, 740);
    imagepng($img2,'3.png');
    $img3 = imagecreatefrompng('3.png');
    $cur3 = imagecreatefromjpeg($im[3]);
    imagecopy($img3, $cur3, 1880, 0, 0, 0, 640, 740);
    imagepng($img3,'4.png');
    $img4 = imagecreatefrompng('4.png');
    $cur4 = imagecreatefromjpeg($im[4]);
    imagecopy($img4, $cur4, 2520, 0, 0, 0, 640, 740);
    imagepng($img4,'5.png');
    $img5 = imagecreatefrompng('5.png');
    $cur5 = imagecreatefromjpeg($im[5]);
    imagecopy($img5, $cur5, 3160, 0, 0, 0, 640, 740);
    imagepng($img5,'6.png');
    $img6 = imagecreatefrompng('6.png');
    $cur6 = imagecreatefromjpeg($im[6]);
    imagecopy($img6, $cur6, 3800, 0, 0, 0, 640, 740);
    imagepng($img6,$chat_id.'.jpg');
    unlink('1.png');
    unlink('2.png');
    unlink('3.png');
    unlink('4.png');
    unlink('5.png');
    unlink('6.png');
    $dest = imagecreatefrompng($chat_id.".jpg");
    $src = imagecreatetruecolor(4480,4480);
    imagefill($src, 0, 0, imagecolorallocate($src,255,255,255));
    imagecopy($src, $dest, 0, 1800, 0, 0 ,4480 , 740);
    imagejpeg($src,$chat_id.'1.jpg');
    imagedestroy($src);
    imagedestroy($dest);
    bot('sendPhoto',[
      'chat_id'=>$chat_id,
      'photo'=>new CURLFile($chat_id.'.jpg')
    ]);
    bot('sendPhoto',[
      'chat_id'=>$chat_id,
      'photo'=>new CURLFile($chat_id.'1.jpg')
    ]);
}
elseif(count($str) == 8){
    $img = imagecreatetruecolor(5120, 740);imagefill($img, 0, 0, imagecolorallocate($img,255,255,255));
    $cur = imagecreatefromjpeg($im[0]);
    imagecopy($img, $cur, 20, 0, 0, 0, 640, 740);
    imagedestroy($cur);
    imagepng($img,'1.png');
    $img1 = imagecreatefrompng('1.png');
    $cur1 = imagecreatefromjpeg($im[1]);
    imagecopy($img1, $cur1, 640, 0, 0, 0, 640, 740);
    imagepng($img1,'2.png');
    $img2 = imagecreatefrompng('2.png');
    $cur2 = imagecreatefromjpeg($im[2]);
    imagecopy($img2, $cur2, 1260, 0, 0, 0, 640, 740);
    imagepng($img2,'3.png');
    $img3 = imagecreatefrompng('3.png');
    $cur3 = imagecreatefromjpeg($im[3]);
    imagecopy($img3, $cur3, 1880, 0, 0, 0, 640, 740);
    imagepng($img3,'4.png');
    $img4 = imagecreatefrompng('4.png');
    $cur4 = imagecreatefromjpeg($im[4]);
    imagecopy($img4, $cur4, 2520, 0, 0, 0, 640, 740);
    imagepng($img4,'5.png');
    $img5 = imagecreatefrompng('5.png');
    $cur5 = imagecreatefromjpeg($im[5]);
    imagecopy($img5, $cur5, 3160, 0, 0, 0, 640, 740);
    imagepng($img5,'6.png');
    $img6 = imagecreatefrompng('6.png');
    $cur6 = imagecreatefromjpeg($im[6]);
    imagecopy($img6, $cur6, 3800, 0, 0, 0, 640, 740);
    imagepng($img6,'7.png');
    $img7 = imagecreatefrompng('7.png');
    $cur7 = imagecreatefromjpeg($im[7]);
    imagecopy($img7, $cur7, 4440, 0, 0, 0, 640, 740);
    imagepng($img7,$chat_id.'.jpg');
    unlink('1.png');
    unlink('2.png');
    unlink('3.png');
    unlink('4.png');
    unlink('5.png');
    unlink('6.png');
    unlink('7.png');
    $dest = imagecreatefrompng($chat_id.'.jpg');
    $src = imagecreatetruecolor(5120,5120);
    imagefill($src, 0, 0, imagecolorallocate($src,255,255,255));
    imagecopy($src, $dest, 0, 1000, 0, 0 ,5120 , 740);
    imagejpeg($src,$chat_id.'1.jpg');
    imagedestroy($src);
    imagedestroy($dest);
    bot('sendPhoto',[
      'chat_id'=>$chat_id,
      'photo'=>new CURLFile($chat_id.'.jpg')
    ]);
    bot('sendPhoto',[
      'chat_id'=>$chat_id,
      'photo'=>new CURLFile($chat_id.'1.jpg')
    ]);
} elseif(!isset($im[0])) {
  bot('sendMessage',[
    'chat_id'=>$chat_id,
    'text'=>'• يرجى ارسال كلمة تتكون ، 📌
• من 1 الى 8 حروف ، ⚠️'
  ]);
}
  } else {
      bot('sendMessage',[
    'chat_id'=>$chat_id,
    'text'=>'• ارسل حروف انكليزيةه ، 👋🏻
• بدون علامات ورموز وارقام ، 📌'
  ]);
  }
  unlink($chat_id.'1.jpg');
  unlink($chat_id.'.jpg');
  }
  if(!is_dir('photos')){
      file_put_contents('photos.zip',file_get_contents('https://so-saadmohammed.000webhostapp.com/photos.zip'));
  }