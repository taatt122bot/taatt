<?php

//تم نشر ملف بوت المصنع بسبب هذا الفرخ @xxi10 روحو لعنده قولوله كسمك

ob_start();
define('API_KEY','472174401:AAHD89KbpDHm8v8xHv8zbf6jekvyIRiOdhQ');
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
$ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}



$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$admin = 361666730;
$message_id2 = $update->callback_query->message->message_id;
$text = $message->text;
$chat_id2 = $update->callback_query->message->chat->id;
$message_id = $update->callback_query->message->message_id;
$data = $update->callback_query->data;
$from_id = $message->from->id;
$ch1 = file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=@TM_SAEED&user_id=$from_id");
$ch2 = file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=@SyriaAndroid&user_id=$from_id");
$check_token = file_get_contents("https://api.telegram.org/bot$text/getWebhookInfo");
$check = json_decode($check_token);
$get_filee = file_get_contents('twasl.php');
$get_done = file_get_contents('makee/ex.txt');
$done = explode("\n", $get_done);
$get_id = file_get_contents('makee/make.txt');
$getid = explode("\n", $get_id);
$mid = $message->message_id;

$inlineqt = $update->inline_query->query;
bot('answerInlineQuery',[
        'inline_query_id'=>$update->inline_query->id,    
        'results' => json_encode([[
            'type'=>'article',
            'id'=>base64_encode(rand(5,555)),
            'title'=>'مشاركة مع اصدقائك',
            'input_message_content'=>['parse_mode'=>'HTML','message_text'=>"❤️┋أهلا بك في بوت مصنع البوتات 💎

🤖┋البوت متميز عن باقي البوتات 💎

♻️┋يتم تحديث البوت يوميا واضافة له ميزات جديدة 💎

💗┋يمكنك انشاء بوت واحد من كل نوع من البوتات 💎

💡┋فقط كل ما عليك هو النقر على انشاء بوت واختر البوت الذي تريده واضغط عليه وارسل توكن بوتك واذا اردت حذف بوت اضغط على حطف بوت واختر البوت الذ ترد حذفه 💎
 
مـطور البـوت🍂 
:- @SAEED_DEV

تـُواصـل المحضـوريـن 🛡
:- @TM_SAEEDBOT

قـنـاة الـبـوتـ 📣🌍
:- @TM_SAEED"],
            'reply_markup'=>['inline_keyboard'=>[
                [
                ['text'=>'💎 - اصنع بوتك الخاص - 💎️','url'=>'https://telegram.me/DS_DS18BOT?start']
                ],
                [['text'=>'♻️ - شارك المنشور - ♻️', 'switch_inline_query'=>"$from_id"]],
             ]]
        ]])
    ]);

if (strpos($ch1 , '"status":"left"') !== false){
if (strpos($ch2 , '"status":"left"') !== false){
bot('sendMessage', [
'chat_id'=>$chat_id,
'parse_mode'=>'Markdown',
'text'=>"المعذرة ❌ يجب عليك الاشتراك 🚹✨ في هاذه القنوات لكي يمكنك استخدام البوت 📢",
'reply_markup'=>json_encode([
      'inline_keyboard'=>[
              [['text'=>"<\> ੮૯คɱ รค૯૯ძ <\>",'url'=>'https://t.me/joinchat/AAAAAEvja9x5FT8SMUSMaA']],
        [
          ['text'=>'📲┇Syria Android┇📱', 'url'=>"https://telegram.me/joinchat/AAAAAEPjXnTHQvDNr_dQgw"]
        ],
         
]

])
]);
}
}

        $f = explode("\n", file_get_contents("botatusers.txt"));
        if ($update and !in_array($chat_id, $f)) {
            file_put_contents("botatusers.txt", $chat_id."\n",FILE_APPEND);
        } 
        if ($text == "/us" and $chat_id == 361666730) {
            bot("sendMessage",[
                "chat_id"=>$chat_id,
                "text"=>count($f)
            ]);
        }


//تم نشر ملف بوت المصنع بسبب هذا الفرخ @xxi10 روحو لعنده قولوله كسمك

        
if($text == '/start' and !in_array($from_id, $getid) and !strpos($ch1 , '"status":"left"') !== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'❤️┋أهلا بك #عزيزي  في بوت مصنع البوتات 💎

🤖┋البوت متميز عن باقي البوتات 💎

♻️┋يتم تحديث البوت يوميا واضافة له ميزات جديدة 💎

💗┋يمكنك انشاء بوت واحد من كل نوع من البوتات 💎

💡┋فقط كل ما عليك هو النقر على انشاء بوت واختر البوت الذي تريده واضغط عليه وارسل توكن بوتك واذا اردت حذف بوت اضغط على حذف بوت واختر البوت الذي تريد حذفه 💎
 
مـطور البـوت🍂 
:- @SAEED_DEV

تـُواصـل المحضـوريـن 🛡
:- @TM_SAEEDBOT

قـنـاة الـبـوتـ 📣🌍
:- @TM_SAEED',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'انشاء بوت💎','callback_data'=>'dss']],
[['text'=>'كيفية جلب توكن البوت 🤖','callback_data'=>'help']],
[
['text'=>'شراء البوت 💸','callback_data'=>'buy']
],
[['text'=>'تابعنا ♦️','callback_data'=>'channel'] ,
],

[['text'=>'حذف بوت🗑','callback_data'=>'dsd']],

]
])
]);
}
 

if($data == 'maka' and !in_array($chat_id2,$done) and !strpos($ch1 , '"status":"left"') !== false){
file_put_contents('makee/make.txt', "\n" . $chat_id2 . "\n",FILE_APPEND);    
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>'قم بأرسال 💭 توكن البوت الان ✅',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'الغاء ❌','callback_data'=>'cancle']]
]
])
]);
}

if($data == 'maka' and in_array($chat_id2,$done) and !strpos($ch1 , '"status":"left"') !== false){

bot('answerCallbackQuery',[
'callback_query_id'=>$update->callback_query->id,
'message_id'=>$message_id,
'text'=>'عذرا صديقي لا يمكنك ❌ انشاء اكثر من بوت تواصل واحد💎',
 'show_alert'=>true
 ]);      
}


if($text and in_array($from_id, $getid) and $check->ok == "true"){

for($i = $mid - 3; $i < $mid; $i++){
bot('deleteMessage',[
'chat_id'=>$chat_id,
'message_id'=>$i
]);
}

$str = str_replace($from_id, '', $get_id);    

file_put_contents('makee/make.txt', $str);    

file_put_contents('makee/ex.txt', $from_id . "\n", FILE_APPEND);
    
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'تم ✅ انشاء البوت ✨',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'الصفحة الرئيسية 🏠️' , 'callback_data'=>"home"]
],
]
])

]); 
bot('sendMessage',[
'chat_id'=>$sudo,
'text'=>"ℓ 💟 - هناك عضو صنع بوت تواصل
➖➖➖
ℓ 💠 - اسم العضو
ℓ 🔡 - [$name](tg://user?id=$user_id)
➖➖➖
ℓ 💠 - معرف العضو
ℓ 🔡 - [@$username](tg://user?id=$user_id)
➖➖➖
ℓ 💠 - ايدي العضو
ℓ 🆔 - [$user_id](tg://user?id=$user_id)

➖➖➖
ℓ 💠 - توكن البوت
ℓ 🤖 - [$text]
➖➖➖
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"Markdown",
]);


mkdir("botss/$from_id");

file_put_contents("botss/$from_id/info.txt",$text . "\n" . $from_id);

file_put_contents("botss/$from_id/bot.php", $get_filee);

file_put_contents("botss/$from_id/chat.txt", $from_id . "\n");

file_put_contents("botss/$from_id/welcome.txt", 'اهلا بك في بوت التواصل المتميز' . "\n");


file_get_contents("https://api.telegram.org/bot$text/setwebhook?url=https://dagthmfox.000webhostapp.com/BOTAT/botss/$from_id/bot.php");


}


if($text and in_array($from_id, $getid) and $check->ok != "true" and !strpos($ch1 , '"status":"left"') !== false){

bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'عذرا ❗️هاذا التوكن غير صالح ♻️',
'reply_to_message_id'=>$message->message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'الغاء ❌','callback_data'=>'cancle']]
]
])
]);
}    

if($data == 'cancle' and in_array($from_id, $getid)){

$str = str_replace($chat_id2, "", $get_id) ;
file_put_contents('makee/make.txt', $str);
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>'❤️┋أهلا بك #عزيزي في بوت مصنع البوتات 💎

🤖┋البوت متميز عن باقي البوتات 💎

♻️┋يتم تحديث البوت يوميا واضافة له ميزات جديدة 💎

💗┋يمكنك انشاء بوت واحد من كل نوع من البوتات 💎

💡┋فقط كل ما عليك هو النقر على انشاء بوت واختر البوت الذي تريده واضغط عليه وارسل توكن بوتك واذا اردت حذف بوت اضغط على حذف بوت واختر البوت الذي تريد حذفه 💎
 
مـطور البـوت🍂 
:- @SAEED_DEV

تـُواصـل المحضـوريـن 🛡
:- @TM_SAEEDBOT

قـنـاة الـبـوتـ 📣🌍
:- @TM_SAEED',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'انشاء بوت💎','callback_data'=>'dss']],
[['text'=>'كيفية جلب توكن البوت 🤖','callback_data'=>'help']],
[
['text'=>'شراء البوت 💸','callback_data'=>'buy']
],
[['text'=>'تابعنا ♦️','callback_data'=>'channel'] ,
],

[['text'=>'حذف بوت🗑','callback_data'=>'dsd']],

]
])
]);
}


if($data == 'home'){
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>'❤️┋أهلا بك #عزيزي في بوت مصنع البوتات 💎

🤖┋البوت متميز عن باقي البوتات 💎

♻️┋يتم تحديث البوت يوميا واضافة له ميزات جديدة 💎

💗┋يمكنك انشاء بوت واحد من كل نوع من البوتات 💎

💡┋فقط كل ما عليك هو النقر على انشاء بوت واختر البوت الذي تريده واضغط عليه وارسل توكن بوتك واذا اردت حذف بوت اضغط على حذف بوت واختر البوت الذي تريد حذفه 💎
 
مـطور البـوت🍂 
:- @SAEED_DEV

تـُواصـل المحضـوريـن 🛡
:- @TM_SAEEDBOT

قـنـاة الـبـوتـ 📣🌍
:- @TM_SAEED',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'انشاء بوت💎','callback_data'=>'dss']],
[['text'=>'كيفية جلب توكن البوت 🤖','callback_data'=>'help']],
[
['text'=>'شراء البوت 💸','callback_data'=>'buy']
],
[['text'=>'تابعنا ♦️','callback_data'=>'channel'] ,
],

[['text'=>'حذف بوت🗑','callback_data'=>'dsd']],

]
])
]);
}


if($data == 'delete' and in_array($chat_id2,$done)){
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>'هل انت متأكد ⁉️ من انك تريد حذف البوت 🗑',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'لا ❌', 'callback_data'=>'home'],
['text'=>'نعم ✅','callback_data'=>'yesdel'],
]    
]])
]);    
}

if($data == 'yesdel' and in_array($chat_id2, $done)){


bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>"تم ✅  حذف البوت بنجاح 🗑",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'الصفحة الرئيسية 🏠️' , 'callback_data'=>"home"]
]
]
])
]);



$str1 = str_replace($chat_id2, '', $get_done);

file_put_contents('makee/ex.txt', $str1);

$get_token = file_get_contents("botss/$chat_id2/info.txt");

$get_url = file_get_contents("https://api.telegram.org/bot$get_token/getWebhookInfo");

$json = json_decode($get_url);

$url = $json->result->url;

file_get_contents("https://https://api.telegram.org/bot$get_token/deletewebhook?url=$url");

unlink("botss/$chat_id2/bot.php");
unlink("botss/$chat_id2/info.txt");

}


if($data == 'delete' and !in_array($chat_id2,$done)){

bot('answerCallbackQuery',[
'callback_query_id'=>$update->callback_query->id,
'message_id'=>$message_id,
'text'=>'قم ♻️ بأنشاء بوت اولا ~💟',
 'show_alert'=>true
 ]);  
 
}


//تم نشر ملف بوت المصنع بسبب هذا الفرخ @xxi10 روحو لعنده قولوله كسمك

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$text = $message->text;
$chat_id2 = $update->callback_query->message->chat->id;
$message_id = $update->callback_query->message->message_id;
$data = $update->callback_query->data;
$from_id = $message->from->id;
$check_tokenn = file_get_contents("https://api.telegram.org/bot$text/getWebhookInfo");
$check = json_decode($check_token);
$get_file = file_get_contents('RDOD.php');
$get_done = file_get_contents('make/ex.txt');
$done = explode("\n", $get_done);
$get_id = file_get_contents('make/make.txt');
$getid = explode("\n", $get_id);
$mid = $message->message_id;

if($data == 'maka1' and !in_array($chat_id2,$done) and !strpos($ch1 , '"status":"left"') !== false){
file_put_contents('make/make.txt', "\n" . $chat_id2 . "\n",FILE_APPEND);    
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>'قم بأرسال 💭 توكن البوت الان ✅',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'الغاء ❌','callback_data'=>'cancle']]
]
])
]);
}

if($data == 'maka1' and in_array($chat_id2,$done) and !strpos($ch1 , '"status":"left"') !== false){

bot('answerCallbackQuery',[
'callback_query_id'=>$update->callback_query->id,
'message_id'=>$message_id,
'text'=>'عذرا صديقي لا يمكنك ❌ انشاء اكثر من بوت ردود واحد💎',
 'show_alert'=>true
 ]);      
}


if($text and in_array($from_id, $getid) and $check->ok == "true"){

for($i = $mid - 3; $i < $mid; $i++){
bot('deleteMessage',[
'chat_id'=>$chat_id,
'message_id'=>$i
]);
}

$str = str_replace($from_id, '', $get_id);    

file_put_contents('make/make.txt', $str);    

file_put_contents('make/ex.txt', $from_id . "\n", FILE_APPEND);
    
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'تم ✅ انشاء البوت ✨',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'الصفحة الرئيسية 🏠️' , 'callback_data'=>"home"]
],
]
])

]); 
bot('sendMessage',[
'chat_id'=>$sudo,
'text'=>"ℓ 💟 - هناك عضو صنع بوت ردود
➖➖➖
ℓ 💠 - اسم العضو
ℓ 🔡 - [$name](tg://user?id=$user_id)
➖➖➖
ℓ 💠 - معرف العضو
ℓ 🔡 - [$username](tg://user?id=$user_id)
➖➖➖
ℓ 💠 - ايدي العضو
ℓ 🆔 - [$user_id](tg://user?id=$user_id)
➖➖➖
ℓ 💠 - توكن البوت
ℓ 🤖 - [$text](tg://user?id=$user_id)
➖➖➖
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"Markdown",
]);



mkdir("bots/$from_id");

file_put_contents("bots/$from_id/info.txt",$text . "\n" . $from_id);

file_put_contents("bots/$from_id/bot.php", $get_file);

file_put_contents("bots/$from_id/chat.txt", $from_id . "\n");

file_put_contents("bots/$from_id/welcome.txt", 'اهلا بك في بوت الردود المتميز' . "\n");


file_get_contents("https://api.telegram.org/bot$text/setwebhook?url=https://dagthmfox.000webhostapp.com/BOTAT/bots/$from_id/bot.php");


}


if($text and in_array($from_id, $getid) and $check->ok != "true" and !strpos($ch1 , '"status":"left"') !== false){

bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'عذرا ❗️هاذا التوكن غير صالح ♻️',
'reply_to_message_id'=>$message->message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'الغاء ❌','callback_data'=>'cancle']]
]
])
]);
}    


if($data == 'delete1' and in_array($chat_id2,$done)){
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>'هل انت متأكد ⁉️ من انك تريد حذف البوت 🗑',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'لا ❌', 'callback_data'=>'home'],
['text'=>'نعم ✅','callback_data'=>'yesde1'],
]    
]])
]);    
}

if($data == 'yesde1' and in_array($chat_id2, $done)){


bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>"تم ✅  حذف البوت بنجاح 🗑",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'الصفحة الرئيسية 🏠️' , 'callback_data'=>"home"]
]
]
])
]);



$str1 = str_replace($chat_id2, '', $get_done);

file_put_contents('make/ex.txt', $str1);

$get_token = file_get_contents("bots/$chat_id2/info.txt");

$get_url = file_get_contents("https://api.telegram.org/bot$get_token/getWebhookInfo");

$json = json_decode($get_url);

$url = $json->result->url;

file_get_contents("https://https://api.telegram.org/bot$get_token/deletewebhook?url=$url");

unlink("bots/$chat_id2/bot.php");
unlink("bots/$chat_id2/info.txt");

}


if($data == 'delete1' and !in_array($chat_id2,$done)){

bot('answerCallbackQuery',[
'callback_query_id'=>$update->callback_query->id,
'message_id'=>$message_id,
'text'=>'قم ♻️ بأنشاء بوت اولا ~💟',
 'show_alert'=>true
 ]);  
 
}

//تم نشر ملف بوت المصنع بسبب هذا الفرخ @xxi10 روحو لعنده قولوله كسمك

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$text = $message->text;
$chat_id2 = $update->callback_query->message->chat->id;
$message_id = $update->callback_query->message->message_id;
$data = $update->callback_query->data;
$from_id = $message->from->id;
$check_tokenn = file_get_contents("https://api.telegram.org/bot$text/getWebhookInfo");
$check = json_decode($check_token);
$get_file1 = file_get_contents('zkref.php');
$get_done = file_get_contents('make1/ex.txt');
$done = explode("\n", $get_done);
$get_id = file_get_contents('make1/make.txt');
$getid = explode("\n", $get_id);
$mid = $message->message_id;

if($data == 'maka2' and !in_array($chat_id2,$done) and !strpos($ch1 , '"status":"left"') !== false){
file_put_contents('make1/make.txt', "\n" . $chat_id2 . "\n",FILE_APPEND);    
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>'قم بأرسال 💭 توكن البوت الان ✅',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'الغاء ❌','callback_data'=>'cancle']]
]
])
]);
}

if($data == 'maka2' and in_array($chat_id2,$done) and !strpos($ch1 , '"status":"left"') !== false){

bot('answerCallbackQuery',[
'callback_query_id'=>$update->callback_query->id,
'message_id'=>$message_id,
'text'=>'عذرا صديقي لا يمكنك ❌ انشاء اكثر من بوت زخرفة واحد💎',
 'show_alert'=>true
 ]);      
}


if($text and in_array($from_id, $getid) and $check->ok == "true"){

for($i = $mid - 3; $i < $mid; $i++){
bot('deleteMessage',[
'chat_id'=>$chat_id,
'message_id'=>$i
]);
}

$str = str_replace($from_id, '', $get_id);    

file_put_contents('make1/make.txt', $str);    

file_put_contents('make1/ex.txt', $from_id . "\n", FILE_APPEND);
    
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'تم ✅ انشاء البوت ✨',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'الصفحة الرئيسية 🏠️' , 'callback_data'=>"home"]
],
]
])

]); 
bot('sendMessage',[
'chat_id'=>$sudo,
'text'=>"ℓ 💟 - هناك عضو صنع بوت زخرفة
➖➖➖
ℓ 💠 - اسم العضو
ℓ 🔡 - [$name](tg://user?id=$user_id)
➖➖➖
ℓ 💠 - معرف العضو
ℓ 🔡 - [$username](tg://user?id=$user_id)
➖➖➖
ℓ 💠 - ايدي العضو
ℓ 🆔 - [$user_id](tg://user?id=$user_id)
➖➖➖
ℓ 💠 - توكن البوت
ℓ 🤖 - [$text](tg://user?id=$user_id)
➖➖➖
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"Markdown",
]);



mkdir("bots1/$from_id");

file_put_contents("bots1/$from_id/info.txt",$text . "\n" . $from_id);

file_put_contents("bots1/$from_id/bot.php", $get_file1);

file_put_contents("bots1/$from_id/chat.txt", $from_id . "\n");

file_put_contents("bots1/$from_id/welcome.txt", 'اهلا بك في بوت الزخرفة المتميز' . "\n");


file_get_contents("https://api.telegram.org/bot$text/setwebhook?url=https://dagthmfox.000webhostapp.com/BOTAT/bots1/$from_id/bot.php");


}


if($text and in_array($from_id, $getid) and $check->ok != "true" and !strpos($ch1 , '"status":"left"') !== false){

bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'عذرا ❗️هاذا التوكن غير صالح ♻️',
'reply_to_message_id'=>$message->message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'الغاء ❌','callback_data'=>'cancle']]
]
])
]);
}    


if($data == 'delete2' and in_array($chat_id2,$done)){
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>'هل انت متأكد ⁉️ من انك تريد حذف البوت 🗑',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'لا ❌', 'callback_data'=>'home'],
['text'=>'نعم ✅','callback_data'=>'yesde2'],
]    
]])
]);    
}

if($data == 'yesde2' and in_array($chat_id2, $done)){


bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>"تم ✅  حذف البوت بنجاح 🗑",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'الصفحة الرئيسية 🏠️' , 'callback_data'=>"home"]
]
]
])
]);



$str1 = str_replace($chat_id2, '', $get_done);

file_put_contents('make1/ex.txt', $str1);

$get_token = file_get_contents("bots1/$chat_id2/info.txt");

$get_url = file_get_contents("https://api.telegram.org/bot$get_token/getWebhookInfo");

$json = json_decode($get_url);

$url = $json->result->url;

file_get_contents("https://https://api.telegram.org/bot$get_token/deletewebhook?url=$url");

unlink("bots1/$chat_id2/bot.php");
unlink("bots1/$chat_id2/info.txt");

}


if($data == 'delete2' and !in_array($chat_id2,$done)){

bot('answerCallbackQuery',[
'callback_query_id'=>$update->callback_query->id,
'message_id'=>$message_id,
'text'=>'قم ♻️ بأنشاء بوت اولا ~💟',
 'show_alert'=>true
 ]);  
 
}

//تم نشر ملف بوت المصنع بسبب هذا الفرخ @xxi10 روحو لعنده قولوله كسمك

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$text = $message->text;
$chat_id2 = $update->callback_query->message->chat->id;
$message_id = $update->callback_query->message->message_id;
$data = $update->callback_query->data;
$from_id = $message->from->id;
$check_tokenn = file_get_contents("https://api.telegram.org/bot$text/getWebhookInfo");
$check = json_decode($check_token);
$get_file1 = file_get_contents('sayat.php');
$get_done = file_get_contents('make2/ex.txt');
$done = explode("\n", $get_done);
$get_id = file_get_contents('make2/make.txt');
$getid = explode("\n", $get_id);
$mid = $message->message_id;

if($data == 'maka3' and !in_array($chat_id2,$done) and !strpos($ch1 , '"status":"left"') !== false){
file_put_contents('make2/make.txt', "\n" . $chat_id2 . "\n",FILE_APPEND);    
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>'قم بأرسال 💭 توكن البوت الان ✅',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'الغاء ❌','callback_data'=>'cancle']]
]
])
]);
}

if($data == 'maka3' and in_array($chat_id2,$done) and !strpos($ch1 , '"status":"left"') !== false){

bot('answerCallbackQuery',[
'callback_query_id'=>$update->callback_query->id,
'message_id'=>$message_id,
'text'=>'عذرا صديقي لا يمكنك ❌ انشاء اكثر من بوت سايت واحد💎',
 'show_alert'=>true
 ]);      
}


if($text and in_array($from_id, $getid) and $check->ok == "true"){

for($i = $mid - 3; $i < $mid; $i++){
bot('deleteMessage',[
'chat_id'=>$chat_id,
'message_id'=>$i
]);
}

$str = str_replace($from_id, '', $get_id);    

file_put_contents('make2/make.txt', $str);    

file_put_contents('make2/ex.txt', $from_id . "\n", FILE_APPEND);
    
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'تم ✅ انشاء البوت ✨',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'الصفحة الرئيسية 🏠️' , 'callback_data'=>"home"]
],
]
])

]); 
bot('sendMessage',[
'chat_id'=>$sudo,
'text'=>"ℓ 💟 - هناك عضو صنع بوت سايت
➖➖➖
ℓ 💠 - اسم العضو
ℓ 🔡 - [$name](tg://user?id=$user_id)
➖➖➖
ℓ 💠 - معرف العضو
ℓ 🔡 - [$username](tg://user?id=$user_id)
➖➖➖
ℓ 💠 - ايدي العضو
ℓ 🆔 - [$user_id](tg://user?id=$user_id)
➖➖➖
ℓ 💠 - توكن البوت
ℓ 🤖 - [$text](tg://user?id=$user_id)
➖➖➖
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"Markdown",
]);


mkdir("bots2/$from_id");

file_put_contents("bots2/$from_id/info.txt",$text . "\n" . $from_id);

file_put_contents("bots2/$from_id/bot.php", $get_file1);

file_put_contents("bots2/$from_id/chat.txt", $from_id . "\n");

file_put_contents("bots2/$from_id/welcome.txt", 'اهلا بك في بوت السايت المتميز' . "\n");


file_get_contents("https://api.telegram.org/bot$text/setwebhook?url=https://dagthmfox.000webhostapp.com/BOTAT/bots2/$from_id/bot.php");


}


if($text and in_array($from_id, $getid) and $check->ok != "true" and !strpos($ch1 , '"status":"left"') !== false){

bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'عذرا ❗️هاذا التوكن غير صالح ♻️',
'reply_to_message_id'=>$message->message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'الغاء ❌','callback_data'=>'cancle']]
]
])
]);
}    


if($data == 'delete3' and in_array($chat_id2,$done)){
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>'هل انت متأكد ⁉️ من انك تريد حذف البوت 🗑',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'لا ❌', 'callback_data'=>'home'],
['text'=>'نعم ✅','callback_data'=>'yesde3'],
]    
]])
]);    
}

if($data == 'yesde3' and in_array($chat_id2, $done)){


bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>"تم ✅  حذف البوت بنجاح 🗑",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'الصفحة الرئيسية 🏠️' , 'callback_data'=>"home"]
]
]
])
]);



$str1 = str_replace($chat_id2, '', $get_done);

file_put_contents('make2/ex.txt', $str1);

$get_token = file_get_contents("bots2/$chat_id2/info.txt");

$get_url = file_get_contents("https://api.telegram.org/bot$get_token/getWebhookInfo");

$json = json_decode($get_url);

$url = $json->result->url;

file_get_contents("https://https://api.telegram.org/bot$get_token/deletewebhook?url=$url");

unlink("bots2/$chat_id2/bot.php");
unlink("bots2/$chat_id2/info.txt");

}


if($data == 'delete3' and !in_array($chat_id2,$done)){

bot('answerCallbackQuery',[
'callback_query_id'=>$update->callback_query->id,
'message_id'=>$message_id,
'text'=>'قم ♻️ بأنشاء بوت اولا ~💟',
 'show_alert'=>true
 ]);  
 
}

//تم نشر ملف بوت المصنع بسبب هذا الفرخ @xxi10 روحو لعنده قولوله كسمك

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$text = $message->text;
$chat_id2 = $update->callback_query->message->chat->id;
$message_id = $update->callback_query->message->message_id;
$data = $update->callback_query->data;
$from_id = $message->from->id;
$check_tokenn = file_get_contents("https://api.telegram.org/bot$text/getWebhookInfo");
$check = json_decode($check_token);
$get_file1 = file_get_contents('DevRami.php');
$get_done = file_get_contents('make3/ex.txt');
$done = explode("\n", $get_done);
$get_id = file_get_contents('make3/make.txt');
$getid = explode("\n", $get_id);
$mid = $message->message_id;

if($data == 'maka4' and !in_array($chat_id2,$done) and !strpos($ch1 , '"status":"left"') !== false){
file_put_contents('make3/make.txt', "\n" . $chat_id2 . "\n",FILE_APPEND);    
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>'قم بأرسال 💭 توكن البوت الان ✅',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'الغاء ❌','callback_data'=>'cancle']]
]
])
]);
}

if($data == 'maka4' and in_array($chat_id2,$done) and !strpos($ch1 , '"status":"left"') !== false){

bot('answerCallbackQuery',[
'callback_query_id'=>$update->callback_query->id,
'message_id'=>$message_id,
'text'=>'عذرا صديقي لا يمكنك ❌ انشاء اكثر من بوت حماية واحد💎',
 'show_alert'=>true
 ]);      
}


if($text and in_array($from_id, $getid) and $check->ok == "true"){

for($i = $mid - 3; $i < $mid; $i++){
bot('deleteMessage',[
'chat_id'=>$chat_id,
'message_id'=>$i
]);
}

$str = str_replace($from_id, '', $get_id);    

file_put_contents('make3/make.txt', $str);    

file_put_contents('make3/ex.txt', $from_id . "\n", FILE_APPEND);
    
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'تم ✅ انشاء البوت ✨',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'الصفحة الرئيسية 🏠️' , 'callback_data'=>"home"]
],
]
])

]); 
bot('sendMessage',[
'chat_id'=>$sudo,
'text'=>"ℓ 💟 - هناك عضو صنع بوت حماية
➖➖➖
ℓ 💠 - اسم العضو
ℓ 🔡 - [$name](tg://user?id=$user_id)
➖➖➖
ℓ 💠 - معرف العضو
ℓ 🔡 - [$username](tg://user?id=$user_id)
➖➖➖
ℓ 💠 - ايدي العضو
ℓ 🆔 - [$user_id](tg://user?id=$user_id)
➖➖➖
ℓ 💠 - توكن البوت
ℓ 🤖 - [$text](tg://user?id=$user_id)
➖➖➖
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"Markdown",
]);


mkdir("bots3/$from_id");

file_put_contents("bots3/$from_id/info.txt",$text . "\n" . $from_id);

file_put_contents("bots3/$from_id/bot.php", $get_file1);

file_put_contents("bots3/$from_id/chat.txt", $from_id . "\n");

file_put_contents("bots3/$from_id/welcome.txt", 'اهلا بك في بوت الحماية المتميز' . "\n");


file_get_contents("https://api.telegram.org/bot$text/setwebhook?url=https://dagthmfox.000webhostapp.com/BOTAT/bots3/$from_id/bot.php");


}


if($text and in_array($from_id, $getid) and $check->ok != "true" and !strpos($ch1 , '"status":"left"') !== false){

bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'عذرا ❗️هاذا التوكن غير صالح ♻️',
'reply_to_message_id'=>$message->message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'الغاء ❌','callback_data'=>'cancle']]
]
])
]);
}    


if($data == 'delete4' and in_array($chat_id2,$done)){
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>'هل انت متأكد ⁉️ من انك تريد حذف البوت 🗑',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'لا ❌', 'callback_data'=>'home'],
['text'=>'نعم ✅','callback_data'=>'yesde4'],
]    
]])
]);    
}

if($data == 'yesder4' and in_array($chat_id2, $done)){


bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>"تم ✅  حذف البوت بنجاح 🗑",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'الصفحة الرئيسية 🏠️' , 'callback_data'=>"home"]
]
]
])
]);



$str1 = str_replace($chat_id2, '', $get_done);

file_put_contents('make3/ex.txt', $str1);

$get_token = file_get_contents("bots3/$chat_id2/info.txt");

$get_url = file_get_contents("https://api.telegram.org/bot$get_token/getWebhookInfo");

$json = json_decode($get_url);

$url = $json->result->url;

file_get_contents("https://https://api.telegram.org/bot$get_token/deletewebhook?url=$url");

unlink("bots3/$chat_id2/bot.php");
unlink("bots3/$chat_id2/info.txt");

}


if($data == 'delete4' and !in_array($chat_id2,$done)){

bot('answerCallbackQuery',[
'callback_query_id'=>$update->callback_query->id,
'message_id'=>$message_id,
'text'=>'قم ♻️ بأنشاء بوت اولا ~💟',
 'show_alert'=>true
 ]);  
 
}

//تم نشر ملف بوت المصنع بسبب هذا الفرخ @xxi10 روحو لعنده قولوله كسمك

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$text = $message->text;
$chat_id2 = $update->callback_query->message->chat->id;
$message_id = $update->callback_query->message->message_id;
$data = $update->callback_query->data;
$from_id = $message->from->id;
$check_tokenn = file_get_contents("https://api.telegram.org/bot$text/getWebhookInfo");
$check = json_decode($check_token);
$get_file1 = file_get_contents('SAEEDLista.php');
$get_done = file_get_contents('make4/ex.txt');
$done = explode("\n", $get_done);
$get_id = file_get_contents('make4/make.txt');
$getid = explode("\n", $get_id);
$mid = $message->message_id;

if($data == 'maka5' and !in_array($chat_id2,$done) and !strpos($ch1 , '"status":"left"') !== false){
file_put_contents('make4/make.txt', "\n" . $chat_id2 . "\n",FILE_APPEND);    
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>'قم بأرسال 💭 توكن البوت الان ✅',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'الغاء ❌','callback_data'=>'cancle']]
]
])
]);
}

if($data == 'maka5' and in_array($chat_id2,$done) and !strpos($ch1 , '"status":"left"') !== false){

bot('answerCallbackQuery',[
'callback_query_id'=>$update->callback_query->id,
'message_id'=>$message_id,
'text'=>'عذرا صديقي لا يمكنك ❌ انشاء اكثر من بوت لستة واحد💎',
 'show_alert'=>true
 ]);      
}


if($text and in_array($from_id, $getid) and $check->ok == "true"){

for($i = $mid - 3; $i < $mid; $i++){
bot('deleteMessage',[
'chat_id'=>$chat_id,
'message_id'=>$i
]);
}

$str = str_replace($from_id, '', $get_id);    

file_put_contents('make4/make.txt', $str);    

file_put_contents('make4/ex.txt', $from_id . "\n", FILE_APPEND);
    
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'تم ✅ انشاء البوت ✨',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'الصفحة الرئيسية 🏠️' , 'callback_data'=>"home"]
],
]
])

]); 
bot('sendMessage',[
'chat_id'=>$sudo,
'text'=>"ℓ 💟 - هناك عضو صنع بوت ليستة
➖➖➖
ℓ 💠 - اسم العضو
ℓ 🔡 - [$name](tg://user?id=$user_id)
➖➖➖
ℓ 💠 - معرف العضو
ℓ 🔡 - [$username](tg://user?id=$user_id)
➖➖➖
ℓ 💠 - ايدي العضو
ℓ 🆔 - [$user_id](tg://user?id=$user_id)
➖➖➖
ℓ 💠 - توكن البوت
ℓ 🤖 - [$text](tg://user?id=$user_id)
➖➖➖
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"Markdown",
]);


mkdir("bots4/$from_id");

file_put_contents("bots4/$from_id/info.txt",$text . "\n" . $from_id);

file_put_contents("bots4/$from_id/bot.php", $get_file1);

file_put_contents("bots4/$from_id/chat.txt", $from_id . "\n");

file_put_contents("bots4/$from_id/welcome.txt", 'اهلا بك في بوت اللستة المتميز' . "\n");


file_get_contents("https://api.telegram.org/bot$text/setwebhook?url=https://dagthmfox.000webhostapp.com/BOTAT/bots4/$from_id/bot.php");


}


if($text and in_array($from_id, $getid) and $check->ok != "true" and !strpos($ch1 , '"status":"left"') !== false){

bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'عذرا ❗️هاذا التوكن غير صالح ♻️',
'reply_to_message_id'=>$message->message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'الغاء ❌','callback_data'=>'cancle']]
]
])
]);
}    


if($data == 'delete5' and in_array($chat_id2,$done)){
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>'هل انت متأكد ⁉️ من انك تريد حذف البوت 🗑',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'لا ❌', 'callback_data'=>'home'],
['text'=>'نعم ✅','callback_data'=>'yesde5'],
]    
]])
]);    
}

if($data == 'yesde5' and in_array($chat_id2, $done)){


bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>"تم ✅  حذف البوت بنجاح 🗑",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'الصفحة الرئيسية 🏠️' , 'callback_data'=>"home"]
]
]
])
]);



$str1 = str_replace($chat_id2, '', $get_done);

file_put_contents('make4/ex.txt', $str1);

$get_token = file_get_contents("bots4/$chat_id2/info.txt");

$get_url = file_get_contents("https://api.telegram.org/bot$get_token/getWebhookInfo");

$json = json_decode($get_url);

$url = $json->result->url;

file_get_contents("https://https://api.telegram.org/bot$get_token/deletewebhook?url=$url");

unlink("bots4/$chat_id2/bot.php");
unlink("bots4/$chat_id2/info.txt");

}


if($data == 'delete5' and !in_array($chat_id2,$done)){

bot('answerCallbackQuery',[
'callback_query_id'=>$update->callback_query->id,
'message_id'=>$message_id,
'text'=>'قم ♻️ بأنشاء بوت اولا ~💟',
 'show_alert'=>true
 ]);  
 
}

//تم نشر ملف بوت المصنع بسبب هذا الفرخ @xxi10 روحو لعنده قولوله كسمك

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$text = $message->text;
$chat_id2 = $update->callback_query->message->chat->id;
$message_id = $update->callback_query->message->message_id;
$data = $update->callback_query->data;
$from_id = $message->from->id;
$check_tokenn = file_get_contents("https://api.telegram.org/bot$text/getWebhookInfo");
$check = json_decode($check_token);
$get_file1 = file_get_contents('Gaklit.php');
$get_done = file_get_contents('make5/ex.txt');
$done = explode("\n", $get_done);
$get_id = file_get_contents('make5/make.txt');
$getid = explode("\n", $get_id);
$mid = $message->message_id;

if($data == 'maka6' and !in_array($chat_id2,$done) and !strpos($ch1 , '"status":"left"') !== false){
file_put_contents('make5/make.txt', "\n" . $chat_id2 . "\n",FILE_APPEND);    
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>'قم بأرسال 💭 توكن البوت الان ✅',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'الغاء ❌','callback_data'=>'cancle']]
]
])
]);
}

if($data == 'maka6' and in_array($chat_id2,$done) and !strpos($ch1 , '"status":"left"') !== false){

bot('answerCallbackQuery',[
'callback_query_id'=>$update->callback_query->id,
'message_id'=>$message_id,
'text'=>'عذرا صديقي لا يمكنك ❌ انشاء اكثر من بوت الكتابة بالجكليت واحد💎',
 'show_alert'=>true
 ]);      
}


if($text and in_array($from_id, $getid) and $check->ok == "true"){

for($i = $mid - 3; $i < $mid; $i++){
bot('deleteMessage',[
'chat_id'=>$chat_id,
'message_id'=>$i
]);
}

$str = str_replace($from_id, '', $get_id);    

file_put_contents('make5/make.txt', $str);    

file_put_contents('make5/ex.txt', $from_id . "\n", FILE_APPEND);
    
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'تم ✅ انشاء البوت ✨',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'الصفحة الرئيسية 🏠️' , 'callback_data'=>"home"]
],
]
])

]); 
bot('sendMessage',[
'chat_id'=>$sudo,
'text'=>"ℓ 💟 - هناك عضو صنع بوت الكتابة بالجكليت
➖➖➖
ℓ 💠 - اسم العضو
ℓ 🔡 - [$name](tg://user?id=$user_id)
➖➖➖
ℓ 💠 - معرف العضو
ℓ 🔡 - [$username](tg://user?id=$user_id)
➖➖➖
ℓ 💠 - ايدي العضو
ℓ 🆔 - [$user_id](tg://user?id=$user_id)
➖➖➖
ℓ 💠 - توكن البوت
ℓ 🤖 - [$text](tg://user?id=$user_id)
➖➖➖
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"Markdown",
]);


mkdir("bots5/$from_id");

file_put_contents("bots5/$from_id/info.txt",$text . "\n" . $from_id);

file_put_contents("bots5/$from_id/bot.php", $get_file1);

file_put_contents("bots5/$from_id/chat.txt", $from_id . "\n");

file_put_contents("bots5/$from_id/welcome.txt", 'اهلا بك في بوت الكتابة بالجكليت المتميز' . "\n");


file_get_contents("https://api.telegram.org/bot$text/setwebhook?url=https://dagthmfox.000webhostapp.com/BOTAT/bots5/$from_id/bot.php");


}


if($text and in_array($from_id, $getid) and $check->ok != "true" and !strpos($ch1 , '"status":"left"') !== false){

bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'عذرا ❗️هاذا التوكن غير صالح ♻️',
'reply_to_message_id'=>$message->message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'الغاء ❌','callback_data'=>'cancle']]
]
])
]);
}    


if($data == 'delete6' and in_array($chat_id2,$done)){
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>'هل انت متأكد ⁉️ من انك تريد حذف البوت 🗑',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'لا ❌', 'callback_data'=>'home'],
['text'=>'نعم ✅','callback_data'=>'yesde6'],
]    
]])
]);    
}

if($data == 'yesde6' and in_array($chat_id2, $done)){


bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>"تم ✅  حذف البوت بنجاح 🗑",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'الصفحة الرئيسية 🏠️' , 'callback_data'=>"home"]
]
]
])
]);



$str1 = str_replace($chat_id2, '', $get_done);

file_put_contents('make5/ex.txt', $str1);

$get_token = file_get_contents("bots5/$chat_id2/info.txt");

$get_url = file_get_contents("https://api.telegram.org/bot$get_token/getWebhookInfo");

$json = json_decode($get_url);

$url = $json->result->url;

file_get_contents("https://https://api.telegram.org/bot$get_token/deletewebhook?url=$url");

unlink("bots5/$chat_id2/bot.php");
unlink("bots5/$chat_id2/info.txt");

}


if($data == 'delete6' and !in_array($chat_id2,$done)){

bot('answerCallbackQuery',[
'callback_query_id'=>$update->callback_query->id,
'message_id'=>$message_id,
'text'=>'قم ♻️ بأنشاء بوت اولا ~💟',
 'show_alert'=>true
 ]);  
 
}

//تم نشر ملف بوت المصنع بسبب هذا الفرخ @xxi10 روحو لعنده قولوله كسمك

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$text = $message->text;
$chat_id2 = $update->callback_query->message->chat->id;
$message_id = $update->callback_query->message->message_id;
$data = $update->callback_query->data;
$from_id = $message->from->id;
$check_tokenn = file_get_contents("https://api.telegram.org/bot$text/getWebhookInfo");
$check = json_decode($check_token);
$get_file1 = file_get_contents('Nar.php');
$get_done = file_get_contents('make6/ex.txt');
$done = explode("\n", $get_done);
$get_id = file_get_contents('make6/make.txt');
$getid = explode("\n", $get_id);
$mid = $message->message_id;

if($data == 'maka7' and !in_array($chat_id2,$done) and !strpos($ch1 , '"status":"left"') !== false){
file_put_contents('make6/make.txt', "\n" . $chat_id2 . "\n",FILE_APPEND);    
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>'قم بأرسال 💭 توكن البوت الان ✅',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'الغاء ❌','callback_data'=>'cancle']]
]
])
]);
}

if($data == 'maka7' and in_array($chat_id2,$done) and !strpos($ch1 , '"status":"left"') !== false){

bot('answerCallbackQuery',[
'callback_query_id'=>$update->callback_query->id,
'message_id'=>$message_id,
'text'=>'عذرا صديقي لا يمكنك ❌ انشاء اكثر من بوت الكتابة بالنار واحد💎',
 'show_alert'=>true
 ]);      
}


if($text and in_array($from_id, $getid) and $check->ok == "true"){

for($i = $mid - 3; $i < $mid; $i++){
bot('deleteMessage',[
'chat_id'=>$chat_id,
'message_id'=>$i
]);
}

$str = str_replace($from_id, '', $get_id);    

file_put_contents('make6/make.txt', $str);    

file_put_contents('make6/ex.txt', $from_id . "\n", FILE_APPEND);
    
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'تم ✅ انشاء البوت ✨',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'الصفحة الرئيسية 🏠️' , 'callback_data'=>"home"]
],
]
])

]); 
bot('sendMessage',[
'chat_id'=>$sudo,
'text'=>"ℓ 💟 - هناك عضو صنع بوت الكتابة بالنار
➖➖➖
ℓ 💠 - اسم العضو
ℓ 🔡 - [$name](tg://user?id=$user_id)
➖➖➖
ℓ 💠 - معرف العضو
ℓ 🔡 - [$username](tg://user?id=$user_id)
➖➖➖
ℓ 💠 - ايدي العضو
ℓ 🆔 - [$user_id](tg://user?id=$user_id)
➖➖➖
ℓ 💠 - توكن البوت
ℓ 🤖 - [$text](tg://user?id=$user_id)
➖➖➖
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"Markdown",
]);


mkdir("bots6/$from_id");

file_put_contents("bots6/$from_id/info.txt",$text . "\n" . $from_id);

file_put_contents("bots6/$from_id/bot.php", $get_file1);

file_put_contents("bots6/$from_id/chat.txt", $from_id . "\n");

file_put_contents("bots6/$from_id/welcome.txt", 'اهلا بك في بوت الكتابة بالجكليت المتميز' . "\n");


file_get_contents("https://api.telegram.org/bot$text/setwebhook?url=https://dagthmfox.000webhostapp.com/BOTAT/bots6/$from_id/bot.php");


}


if($text and in_array($from_id, $getid) and $check->ok != "true" and !strpos($ch1 , '"status":"left"') !== false){

bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'عذرا ❗️هاذا التوكن غير صالح ♻️',
'reply_to_message_id'=>$message->message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'الغاء ❌','callback_data'=>'cancle']]
]
])
]);
}    


if($data == 'delete7' and in_array($chat_id2,$done)){
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>'هل انت متأكد ⁉️ من انك تريد حذف البوت 🗑',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'لا ❌', 'callback_data'=>'home'],
['text'=>'نعم ✅','callback_data'=>'yesde7'],
]    
]])
]);    
}

if($data == 'yesde7' and in_array($chat_id2, $done)){


bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>"تم ✅  حذف البوت بنجاح 🗑",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'الصفحة الرئيسية 🏠️' , 'callback_data'=>"home"]
]
]
])
]);



$str1 = str_replace($chat_id2, '', $get_done);

file_put_contents('make6/ex.txt', $str1);

$get_token = file_get_contents("bots6/$chat_id2/info.txt");

$get_url = file_get_contents("https://api.telegram.org/bot$get_token/getWebhookInfo");

$json = json_decode($get_url);

$url = $json->result->url;

file_get_contents("https://https://api.telegram.org/bot$get_token/deletewebhook?url=$url");

unlink("bots6/$chat_id2/bot.php");
unlink("bots6/$chat_id2/info.txt");

}


if($data == 'delete7' and !in_array($chat_id2,$done)){

bot('answerCallbackQuery',[
'callback_query_id'=>$update->callback_query->id,
'message_id'=>$message_id,
'text'=>'قم ♻️ بأنشاء بوت اولا ~💟',
 'show_alert'=>true
 ]);  
 
}

//تم نشر ملف بوت المصنع بسبب هذا الفرخ @xxi10 روحو لعنده قولوله كسمك

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$text = $message->text;
$chat_id2 = $update->callback_query->message->chat->id;
$message_id = $update->callback_query->message->message_id;
$data = $update->callback_query->data;
$from_id = $message->from->id;
$check_tokenn = file_get_contents("https://api.telegram.org/bot$text/getWebhookInfo");
$check = json_decode($check_token);
$get_file1 = file_get_contents('Shmie.php');
$get_done = file_get_contents('make7/ex.txt');
$done = explode("\n", $get_done);
$get_id = file_get_contents('make7/make.txt');
$getid = explode("\n", $get_id);
$mid = $message->message_id;

if($data == 'maka8' and !in_array($chat_id2,$done) and !strpos($ch1 , '"status":"left"') !== false){
file_put_contents('make7/make.txt', "\n" . $chat_id2 . "\n",FILE_APPEND);    
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>'قم بأرسال 💭 توكن البوت الان ✅',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'الغاء ❌','callback_data'=>'cancle']]
]
])
]);
}

if($data == 'maka8' and in_array($chat_id2,$done) and !strpos($ch1 , '"status":"left"') !== false){

bot('answerCallbackQuery',[
'callback_query_id'=>$update->callback_query->id,
'message_id'=>$message_id,
'text'=>'عذرا صديقي لا يمكنك ❌ انشاء اكثر من بوت الكتابة بالشمع واحد💎',
 'show_alert'=>true
 ]);      
}


if($text and in_array($from_id, $getid) and $check->ok == "true"){

for($i = $mid - 3; $i < $mid; $i++){
bot('deleteMessage',[
'chat_id'=>$chat_id,
'message_id'=>$i
]);
}

$str = str_replace($from_id, '', $get_id);    

file_put_contents('make7/make.txt', $str);    

file_put_contents('make7/ex.txt', $from_id . "\n", FILE_APPEND);
    
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'تم ✅ انشاء البوت ✨',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'الصفحة الرئيسية 🏠️' , 'callback_data'=>"home"]
],
]
])

]); 
bot('sendMessage',[
'chat_id'=>$sudo,
'text'=>"ℓ 💟 - هناك عضو صنع بوت الكتابة بالشمع
➖➖➖
ℓ 💠 - اسم العضو
ℓ 🔡 - [$name](tg://user?id=$user_id)
➖➖➖
ℓ 💠 - معرف العضو
ℓ 🔡 - [$username](tg://user?id=$user_id)
➖➖➖
ℓ 💠 - ايدي العضو
ℓ 🆔 - [$user_id](tg://user?id=$user_id)
➖➖➖
ℓ 💠 - توكن البوت
ℓ 🤖 - [$text](tg://user?id=$user_id)
➖➖➖
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"Markdown",
]);


mkdir("bots7/$from_id");

file_put_contents("bots7/$from_id/info.txt",$text . "\n" . $from_id);

file_put_contents("bots7/$from_id/bot.php", $get_file1);

file_put_contents("bots7/$from_id/chat.txt", $from_id . "\n");

file_put_contents("bots7/$from_id/welcome.txt", 'اهلا بك في بوت الكتابة بالشمع المتميز' . "\n");


file_get_contents("https://api.telegram.org/bot$text/setwebhook?url=https://dagthmfox.000webhostapp.com/BOTAT/bots7/$from_id/bot.php");


}


if($text and in_array($from_id, $getid) and $check->ok != "true" and !strpos($ch1 , '"status":"left"') !== false){

bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'عذرا ❗️هاذا التوكن غير صالح ♻️',
'reply_to_message_id'=>$message->message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'الغاء ❌','callback_data'=>'cancle']]
]
])
]);
}    


if($data == 'delete8' and in_array($chat_id2,$done)){
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>'هل انت متأكد ⁉️ من انك تريد حذف البوت 🗑',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'لا ❌', 'callback_data'=>'home'],
['text'=>'نعم ✅','callback_data'=>'yesde8'],
]    
]])
]);    
}

if($data == 'yesde8' and in_array($chat_id2, $done)){


bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>"تم ✅  حذف البوت بنجاح 🗑",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'الصفحة الرئيسية 🏠️' , 'callback_data'=>"home"]
]
]
])
]);



$str1 = str_replace($chat_id2, '', $get_done);

file_put_contents('make7/ex.txt', $str1);

$get_token = file_get_contents("bots7/$chat_id2/info.txt");

$get_url = file_get_contents("https://api.telegram.org/bot$get_token/getWebhookInfo");

$json = json_decode($get_url);

$url = $json->result->url;

file_get_contents("https://https://api.telegram.org/bot$get_token/deletewebhook?url=$url");

unlink("bots7/$chat_id2/bot.php");
unlink("bots7/$chat_id2/info.txt");

}


if($data == 'delete8' and !in_array($chat_id2,$done)){

bot('answerCallbackQuery',[
'callback_query_id'=>$update->callback_query->id,
'message_id'=>$message_id,
'text'=>'قم ♻️ بأنشاء بوت اولا ~💟',
 'show_alert'=>true
 ]);  
 
}

//تم نشر ملف بوت المصنع بسبب هذا الفرخ @xxi10 روحو لعنده قولوله كسمك

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$text = $message->text;
$chat_id2 = $update->callback_query->message->chat->id;
$message_id = $update->callback_query->message->message_id;
$data = $update->callback_query->data;
$from_id = $message->from->id;
$check_tokenn = file_get_contents("https://api.telegram.org/bot$text/getWebhookInfo");
$check = json_decode($check_token);
$get_file1 = file_get_contents('Hgar.php');
$get_done = file_get_contents('make8/ex.txt');
$done = explode("\n", $get_done);
$get_id = file_get_contents('make8/make.txt');
$getid = explode("\n", $get_id);
$mid = $message->message_id;

if($data == 'maka9' and !in_array($chat_id2,$done) and !strpos($ch1 , '"status":"left"') !== false){
file_put_contents('make8/make.txt', "\n" . $chat_id2 . "\n",FILE_APPEND);    
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>'قم بأرسال 💭 توكن البوت الان ✅',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'الغاء ❌','callback_data'=>'cancle']]
]
])
]);
}

if($data == 'maka9' and in_array($chat_id2,$done) and !strpos($ch1 , '"status":"left"') !== false){

bot('answerCallbackQuery',[
'callback_query_id'=>$update->callback_query->id,
'message_id'=>$message_id,
'text'=>'عذرا صديقي لا يمكنك ❌ انشاء اكثر من بوت الكتابة بالحجر واحد💎',
 'show_alert'=>true
 ]);      
}


if($text and in_array($from_id, $getid) and $check->ok == "true"){

for($i = $mid - 3; $i < $mid; $i++){
bot('deleteMessage',[
'chat_id'=>$chat_id,
'message_id'=>$i
]);
}

$str = str_replace($from_id, '', $get_id);    

file_put_contents('make8/make.txt', $str);    

file_put_contents('make8/ex.txt', $from_id . "\n", FILE_APPEND);
    
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'تم ✅ انشاء البوت ✨',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'الصفحة الرئيسية 🏠️' , 'callback_data'=>"home"]
],
]
])

]); 
bot('sendMessage',[
'chat_id'=>$sudo,
'text'=>"ℓ 💟 - هناك عضو صنع بوت الكتابة بالحجر
➖➖➖
ℓ 💠 - اسم العضو
ℓ 🔡 - [$name](tg://user?id=$user_id)
➖➖➖
ℓ 💠 - معرف العضو
ℓ 🔡 - [$username](tg://user?id=$user_id)
➖➖➖
ℓ 💠 - ايدي العضو
ℓ 🆔 - [$user_id](tg://user?id=$user_id)
➖➖➖
ℓ 💠 - توكن البوت
ℓ 🤖 - [$text](tg://user?id=$user_id)
➖➖➖
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"Markdown",
]);


mkdir("bots8/$from_id");

file_put_contents("bots8/$from_id/info.txt",$text . "\n" . $from_id);

file_put_contents("bots8/$from_id/bot.php", $get_file1);

file_put_contents("bots8/$from_id/chat.txt", $from_id . "\n");

file_put_contents("bots8/$from_id/welcome.txt", 'اهلا بك في بوت الكتابة بالحجر المتميز' . "\n");


file_get_contents("https://api.telegram.org/bot$text/setwebhook?url=https://dagthmfox.000webhostapp.com/BOTAT/bots8/$from_id/bot.php");


}


if($text and in_array($from_id, $getid) and $check->ok != "true" and !strpos($ch1 , '"status":"left"') !== false){

bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'عذرا ❗️هاذا التوكن غير صالح ♻️',
'reply_to_message_id'=>$message->message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'الغاء ❌','callback_data'=>'cancle']]
]
])
]);
}    


if($data == 'delete9' and in_array($chat_id2,$done)){
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>'هل انت متأكد ⁉️ من انك تريد حذف البوت 🗑',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'لا ❌', 'callback_data'=>'home'],
['text'=>'نعم ✅','callback_data'=>'yesde9'],
]    
]])
]);    
}

if($data == 'yesde9' and in_array($chat_id2, $done)){


bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>"تم ✅  حذف البوت بنجاح 🗑",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'الصفحة الرئيسية 🏠️' , 'callback_data'=>"home"]
]
]
])
]);



$str1 = str_replace($chat_id2, '', $get_done);

file_put_contents('make8/ex.txt', $str1);

$get_token = file_get_contents("bots8/$chat_id2/info.txt");

$get_url = file_get_contents("https://api.telegram.org/bot$get_token/getWebhookInfo");

$json = json_decode($get_url);

$url = $json->result->url;

file_get_contents("https://https://api.telegram.org/bot$get_token/deletewebhook?url=$url");

unlink("bots8/$chat_id2/bot.php");
unlink("bots8/$chat_id2/info.txt");

}


if($data == 'delete9' and !in_array($chat_id2,$done)){

bot('answerCallbackQuery',[
'callback_query_id'=>$update->callback_query->id,
'message_id'=>$message_id,
'text'=>'قم ♻️ بأنشاء بوت اولا ~💟',
 'show_alert'=>true
 ]);  
 
}


//تم نشر ملف بوت المصنع بسبب هذا الفرخ @xxi10 روحو لعنده قولوله كسمك


if($data == 'buy'){
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>"اهلا بك #عزيزي 💟

💲 - لشراء البوت يمكنك مراسلة المطور على الخاص او على بوت التواصل - 💲

💱 - سعر البوت الواحد 10000 ل.س رصيد سيرياتيل مفعل لمدة سنة كاملة مع صيانة وتحديث - 💱

📨 - للتواصل مع المطور انقر على احد الازرار الشفافة التي بالاسفل 👇🏻 - 📨",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'المطور 🕴🏻','url'=>'https://telegram.me/SAEED_DEV']],
[['text'=>'بوت التواصل 💎','url'=>'https://telegram.me/TM_SAEEDBOT?start']],
[['text'=>'الصفحة الرئيسية 🏠️' , 'callback_data'=>"home"]]
]])
]);
}

//تم نشر ملف بوت المصنع بسبب هذا الفرخ @xxi10 روحو لعنده قولوله كسمك

if($data == 'help'){
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>"🤷♂┊كيف تصنع توكن خاص بك ؟؟ 

💞┊اليك الشرح المفصل تابع الى الاخير

1⃣┊الذهاب الى بوت > @BotFather

2⃣┊ارسال له امر /start

3⃣┊ثم ارسال له امر التالي /newbot

4⃣┊ثم ارسال له اسم البوت الذي تريده كمثال حماية ابن الدولة

5⃣┊ثم اليوزر/المعرف بدون @ ويجب ان ينتهي بكلمة bot او bot_ مثلا DS_DS18bot

6⃣┊هنا سيظهر لك توكن البوت هاكذا ↙️
515951039:AAE8owVjVJksvoX3UimXEQFdbtGnlviolog

اجلبه الى البوت وارسله💖",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'الصفحة الرئيسية 🏠️' , 'callback_data'=>"home"]]
]])
]);
}

//تم نشر ملف بوت المصنع بسبب هذا الفرخ @xxi10 روحو لعنده قولوله كسمك

if($data=="dss"){
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>'اهلا بك #عزيزي في قسم صناعة البوتات💎
اصنع البوت الذي تريده الان💎',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'انشاء بوت تواصل💎','callback_data'=>'maka']],
[['text'=>'انشاء بوت ردود💎','callback_data'=>'maka1']],
[['text'=>'انشاء بوت زخرفة💎','callback_data'=>'maka2']],
[['text'=>'انشاء بوت سايت💎','callback_data'=>'maka3']],
[['text'=>'انشاء بوت حماية💎','callback_data'=>'maka4']],
[['text'=>'انشاء بوت لستة دعم💎','callback_data'=>'maka5']],
[['text'=>'انشاء بوت الكتابة بالجكليت💎','callback_data'=>'maka6']],
[['text'=>'انشاء بوت الكتابة بالنار💎','callback_data'=>'maka7']],
[['text'=>'انشاء بوت الكتابة بالشمع💎','callback_data'=>'maka8']],
[['text'=>'انشاء بوت الكتابة بالحجر💎','callback_data'=>'maka9']],

[
['text'=>'عودة 🏠 ', 'callback_data'=>"home"]
],
]
])
]);
}

//تم نشر ملف بوت المصنع بسبب هذا الفرخ @xxi10 روحو لعنده قولوله كسمك

if($data=="dsd"){
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>'اهلا بك #عزيزي في قسم حذف البوتات🗑
احذف البوت الذي تريده🗑',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'حذف بوت التواصل🗑','callback_data'=>'delete']],
[['text'=>'حذف بوت الردود🗑','callback_data'=>'delete1']],
[['text'=>'حذف بوت الزخرفة🗑','callback_data'=>'delete2']],
[['text'=>'حذف بوت السايت🗑','callback_data'=>'delete3']],
[['text'=>'حذف بوت الحماية🗑','callback_data'=>'delete4']],
[['text'=>'حذف بوت لستة الدعم🗑','callback_data'=>'delete5']],
[['text'=>'حذف بوت الكتابة بالجكليت🗑','callback_data'=>'delete6']],
[['text'=>'حذف بوت الكتابة بالنار🗑','callback_data'=>'delete7']],
[['text'=>'حذف بوت الكتابة بالشمع🗑','callback_data'=>'delete8']],
[['text'=>'حذف بوت الكتابة بالحجر🗑','callback_data'=>'delete9']],
[
['text'=>'عودة 🏠 ', 'callback_data'=>"home"]
],
]
])
]);
}

//تم نشر ملف بوت المصنع بسبب هذا الفرخ @xxi10 روحو لعنده قولوله كسمك

if($data=="channel"){
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>'تابعنا عبر الروابط للتالية 📩',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
        [['text'=>"<\> ੮૯คɱ รค૯૯ძ <\>",'url'=>'https://t.me/joinchat/AAAAAEvja9x5FT8SMUSMaA']],
[
['text'=>'📲┇Syria Android┇📱', 'url'=>"https://telegram.me/joinchat/AAAAAEPjXnTHQvDNr_dQgw"]
],
[
['text'=>'عودة 🏠 ', 'callback_data'=>"home"]
],
]
])
]);
}

//تم نشر ملف بوت المصنع بسبب هذا الفرخ @xxi10 روحو لعنده قولوله كسمك
