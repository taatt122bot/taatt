<?php 

//تم نشر ملف بوت المصنع بسبب هذ الفرخ @xxi10 روحو لعنده قولوله كسمك

$get_toke = file_get_contents('info.txt');

$get_token = explode("\n", $get_toke);


$url_info = file_get_contents("https://api.telegram.org/bot$get_token[0]/getMe");

$json_info = json_decode($url_info);

$user = $json_info->result->username;

$bot_id = $json_info->result->id;

$admin = $get_token[1];

ob_start();

$API_KEY = $get_token[0];
define('API_KEY',$API_KEY);
echo "api.telegram.org/bot".API_KEY."/setwebhook?url=".$_SERVER['SERVER_NAME']."".$_SERVER['SCRIPT_NAME'];
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
  }
#                     SAJAD                       #
$update = json_decode(file_get_contents('php://input'));
$from_id = $update->message->from->id; 
$chat_id = $update->message->chat->id;
$text = $update->message->text;
$message = $update->message;
$chat_id2 = $update->callback_query->message->chat->id;
$message_id = $update->callback_query->message->message_id;
$data = $update->callback_query->data;
$admin = $get_token[1];
$rep = $message->reply_to_message;
$json = json_decode(file_get_contents('data.json'),true);
if ($text and !in_array($chat_id, explode("\n", file_get_contents('mem.txt')))) {
    file_put_contents('mem.txt', $chat_id."\n",FILE_APPEND);
}
$sudo = $get_token[1];
$name = $message->from->first_name;
$user_id = $message->from->id;
$username = $message->from->username; 

if (!file_exists('data.json')) {
    $js = array('start' => 'مرحبا بك في بوت السايت 👀
ارسل ماتريد وسيتم ارساله بهويه مجهوله الى صاحب البوت ✅' );
    file_put_contents('data.json', json_encode($js));
}
if ($chat_id == $admin || $chat_id2 == $admin) {
    if ($text == "/start") {
        bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>'مرحبا بك في بوت السايت الخاص بك 📩',
            'reply_markup'=>json_encode([
                'inline_keyboard'=>[
                [['text'=>"الاوامر والميزات ⚙️",'callback_data'=>'commands']],
                [['text'=>'عدد اعضاء بوتك 👥','callback_data'=>'mem']],
                [['text'=>'ارسال رساله للكل 🗣','callback_data'=>'post']],
                [['text'=>'تغيير رساله البدء 👀 ','callback_data'=>'start']]
                ]])
            ]); 
    }
    if ($data == 'back') {
        unlink('mode.txt');
        bot('editMessageText',[
            'chat_id'=>$chat_id2,
            'message_id'=>$message_id,
            'text'=>'مرحبا بك في بوت السايت الخاص بك 📩',
            'reply_markup'=>json_encode([
                'inline_keyboard'=>[
                [['text'=>"الاوامر والميزات ⚙️",'callback_data'=>'commands']],
                [['text'=>'عدد اعضاء بوتك 👥','callback_data'=>'mem']],
                [['text'=>'ارسال رساله للكل 🗣','callback_data'=>'post']],
                [['text'=>'تغيير رساله البدء 👀 ','callback_data'=>'start']]
                ]])
            ]);
    }
    if ($data == 'commands') {
        bot('editMessageText',[
            'chat_id'=>$chat_id2,
            'message_id'=>$message_id,
            'text'=>'مرحبا بك مره اخرى 👋🏻
مميزات البوت هي  🕸 :  
1- يمكنك الرد على رسائل الاشخاص 
2- يمكنك حظر الاشخاص من البوت ( عن طريق الرد على الرساله وارسال كلمه حظر)
3- تستطيع االغاء حظر الاشخاص ( عن طريق الرد على الرساله وارسال كلمه الغاء ) حظر
4- يظهر لك عدد اعضاء البوت 
5- تستطيع ارسال رساله الى الكل 
6- تغيير رساله البدء
ومميزات اكثر كالسرعه وغيرها يمكنك اكتشافها بنفسك ✅',
            'reply_markup'=>json_encode([
                'inline_keyboard'=>[
                [['text'=>'رجوع 🔙','callback_data'=>'back']]
                ]])
            ]);
    }
    if ($data == 'mem') {
        $c = count(explode("\n", file_get_contents('mem.txt')));
        bot('editMessageText',[
            'chat_id'=>$chat_id2,
            'message_id'=>$message_id,
            'text'=>"عدد اعضاء بوتك هو :- $c 👥",
            'reply_markup'=>json_encode([
                'inline_keyboard'=>[
                [['text'=>'رجوع 🔙','callback_data'=>'back']]
                ]])
            ]);
    }
    if ($data == 'post') {
    file_put_contents('mode.txt', 'data');
    bot('editMessageText',[
            'chat_id'=>$chat_id2,
            'message_id'=>$message_id,
            'text'=>"ارسل الرساله التي تريدها 👥",
            'reply_markup'=>json_encode([
                'inline_keyboard'=>[
                [['text'=>'رجوع 🔙','callback_data'=>'back']]
                ]])
            ]);
    }
    if ($text and file_get_contents('mode.txt') == 'data') {
        $c = explode("\n", file_get_contents('mem.txt'));
        for ($i=0; $i < count($c); $i++) { 
            bot('sendMessage',[
                'chat_id'=>$c[$i],
                'text'=>$text,
                ]);
        }
        $c = count(explode("\n", file_get_contents('mem.txt')));
        bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"تم الارسال الى 🗣 : $c"
            ]); 
        unlink('mode.txt');
    }
    if ($data == 'start') {
        file_put_contents('mode.txt', 'start');
        bot('editMessageText',[
            'chat_id'=>$chat_id2,
            'message_id'=>$message_id,
            'text'=>"ارسل الرساله التي تريدها 👥",
            'reply_markup'=>json_encode([
                'inline_keyboard'=>[
                [['text'=>'رجوع 🔙','callback_data'=>'back']]
                ]])
            ]);
    }
    if ($text and file_get_contents('mode.txt') == 'start') {
        $json['start'] = $text;
        file_put_contents("data.json", json_encode($json));
        bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"تم تغيير رسال البدء الى 🗣 : $text"
            ]); 
        unlink('mode.txt');
    }
    if ($rep and $text != 'حظر') {
        bot('sendMessage',[
            'chat_id'=>$json['msgs'][$rep->text],
            'text'=>$text
            ]);
    }
    if ($rep and $text == 'حظر') {
        file_put_contents('bans.txt', $json['msgs'][$rep->text]."\n",FILE_APPEND);
        bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"تم الحظر بنجاح 🚫",
            ]); 
        bot('sendMessage',[
            'chat_id'=>$json['msgs'][$rep->text],
            'text'=>'لقد تم حظرك من البوت 🚫'
            ]);
    }
    if ($rep and $text == 'الغاء حظر') {
        file_put_contents('bans.txt', str_replace($json['msgs'][$rep->text], '', file_get_contents('bans.txt')));
        bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"تم الغاء الحظر بنجاح ✅",
            ]); 
        bot('sendMessage',[
            'chat_id'=>$json['msgs'][$rep->text],
            'text'=>'لقد تم الغاء حظرك من البوت ✅'
            ]);
    
    }
} else {

    if ($text == '/start') {
        bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>$json['start']."\n\n

〰〰〰〰〰〰〰〰〰〰",
            
             'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'🔧 اصنع بوتك الخاص 🔧','url'=>'https://telegram.me/DS_DS18BOT?start']],
]
        ])
            ]);
        }

    if ($text != '/start' and !in_array($chat_id, explode("\n", file_get_contents('bans.txt')))) {
        $json['msgs'][$text] = $chat_id;
        file_put_contents("data.json", json_encode($json));
        bot('sendMessage',[
            'chat_id'=>$admin,
            'text'=>$text
            ]);
        bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"تم ✅ ارسال رسالتك بهوية مجهولة 📩",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'🔧 اصنع بوتك الخاص 🔧','url'=>'https://telegram.me/DS_DS18BOT?start']],
]
        ])
            ]);
}
    if($message->photo){
 bot('sendPhoto',[
  'chat_id'=>$admin,
  'photo'=>$message->photo[0]->file_id
  ]);
}
if($message->video){
 bot('sendVideo',[
  'chat_id'=>$sudo,
  'video'=>$message->video->file_id
  ]);
}
if($message->voice){
 bot('sendvoice',[
  'chat_id'=>$admin,
  'voice'=>$message->voice->file_id
  ]);
}
if($message->audio){
 bot('sendaudio',[
  'chat_id'=>$admin,
  'audio'=>$message->audio->file_id
 ]);
}
if($message->sticker){
 bot('sendsticker',[

'chat_id'=>$admin,
  'sticker'=>$message->sticker->file_id
 ]);
}
    if ($text != '/start' and in_array($chat_id, explode("\n", file_get_contents('bans.txt')))) {
        bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"انت محظور لا يمكنك ارسال شيء 🚫",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'🔧 اصنع بوتك الخاص 🔧','url'=>'https://telegram.me/DS_DS18BOT?start']],
]
        ])
            ]);
    }
}