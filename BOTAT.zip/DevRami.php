<?php

//تم نشر ملف بوت المصنع بسبب تذا الفرخ @xxi10 روحو لعنده قولوله كسمك


//@SyriaAndroid //@DS_DS
#----ابـৡـن_الـৡـدولـৡـۂ_الـৡـادلـৡـبـৡـيـৡـۂ----#

$get_toke = file_get_contents('info.txt');

$get_token = explode("\n", $get_toke);


$url_info = file_get_contents("https://api.telegram.org/bot$get_token[0]/getMe");

$json_info = json_decode($url_info);

$user = $json_info->result->username;

$bot_id = $json_info->result->id;

$admin = $get_token[1];

ob_start();

$API_KEY = $get_token[0];
define('API_KEY',$API_KEY);
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$text = $message->text;
$name = $message->from->first_name;
$fwd = $message->forward_from_chat->id;
$new_member = $update->message->new_chat_member; 
$left = $update->message->left_chat_member; 
$textmsg = $message->text;
$message_id = $message->message_id;
$rep = $message->reply_to_message; 
$rep_msg = $rep->message_id; 
$id_sudo = $get_token[1];
$get = file_get_contents('file.txt');
$ex = explode("\n", $get);
$count = count($ex);
$type = $update->message->chat->type;
$re = $update->message->reply_to_message;
$re_id = $update->message->reply_to_message->from->id;
$re_user = $update->message->reply_to_message->from->username;
$user_id = $update->message->from->id;
$re_name = $update->message->reply_to_message->from->first_name;
$re_msgid = $update->message->reply_to_message->message_id;
$name = $message->from->name;
$username = $message->from->username;
$chat_id2 = $update->callback_query->message->chat->id;
$message_id = $update->message->message_id;
$id = $message->from->id;
$time = time() + (979 * 11 + 1 + 30);



if($text == 'تفعيل'){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"✅➖تم➖تفعيل➖بوت➖الردود ➖والحمايه➖ارسل➖(الاوامر)➖لمعرفة➖الاوامر➖✅",
]);
}
if($text == "/start"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"اهلا بك #عزيزي في بوت الحماية والردود❤️
{-------------------------------------------------------}
من خلال هذا البوت يمكنك حماية مجموعتك وبسهولة تامة💗

كل ماعليك رفع البوت ادمن في كروبك ومن ثم ارسل امر تفعيل💞

اذا اردت عرض الاوامر ارسل (الاوامر)💓
{-------------------------------------------------------}
`اصنع بوتك الخاص🔧`:
@DS_DS18BOT",
'reply_to_message_id'=>$message->$message_id,
]);
}
if($text == "الاوامر"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"مـرحـبـا بـك 🌹
فـي ا໑امـﮩر الـحـمـايـة الـمـجـمـوعـة 🎋🙂
{-------------------------------------------------------}
قفل 🔐| فتح 🔓> الروابط 📎
قفل 🔐| فتح 🔓> التوجيه 🔄
قفل 🔐| فتح 🔓> الالعاب 📊
قفل 🔐| فتح 🔓> البصمات 🎙
قفل 🔐| فتح 🔓> البصمات 🔕
قفل 🔐| فتح 🔓> الصور 🏞
قفل 🔐| فتح 🔓> الفيديو 🎥
قفل 🔐| فتح 🔓> الملصقات ⚡️
قفل 🔐| فتح 🔓> جهات الاتصال 📞
{-------------------------------------------------------}
`اصنع بوتك الخاص🔧`:
@DS_DS18BOT",
'reply_to_message_id'=>$message->$message_id,
]);
}
if($text == "شكو ماكو"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"سلامتك",
'reply_to_message_id'=>$message->$message_id,
]);
}
if($text == "شلونك"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"تمام",
'reply_to_message_id'=>$message->$message_id,
]);
}
if($text == "تحبني"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"اعشقك",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "انجب"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"اكيد",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "جذاب"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"لا",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "ها"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"وجعا",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "ولي"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"دي",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "احبك"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"واني هم",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "حلو"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"ٱنـﮩـت الاحـلا",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "😎"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"يلا عود انته فد نعال",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "😱"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"خير خوفتني ",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "منو اكثر واحد"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"خالتك",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "منو اكثر واحد"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"وك اسف 🙁",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "ابن الكلب"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"عيب ابني 🔥",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "كواد"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"عيب 😨�🔥",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "حيدر"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" ؤرده مال الله هاذا",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "قندره"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"😂بحلكك😂",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "هلو"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"هـﮩـڵآوات",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "هلا"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"✾  هـﮩـڵا ہبـﮩـک ",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "مرحبا"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"  مٌـﮩۚـرحـﮩۘـتين",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "كاسبر"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"راح يلتحق عوفه بنلخرا",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "☹️"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"لـﮩـضـوج פـٍـٍبيبي",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "ههه"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"دوم פـٍـٍبيبي",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "هههه"){
bot('sendMessage',[
'chat_id'=>$chat_id,

'text'=>"دوم פـٍـٍبيبي",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "ههههه"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"دوم פـٍـٍبيبي",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "هههههه"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"دوم פـٍـٍبيبي",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "😍"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"عود فرحان الوصخ",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "☺️"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"اكعد راحه سمير",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "💋"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"انته غير سافل",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "😘"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"بنيه كدامك مثلا",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "🙈"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"عود يستحي الوصخ",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "😐"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"كبر لفك",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "😞"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"ع شنو ضايج",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "🚶"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"وين جاي وين مولي",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "ضوجه"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"واني شعليه مثلا شسؤيلك",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "😻"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"ع شنو فرحان😒",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "😞"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"يمه فدوه ضايج الحلو🙊",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "😹"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"شعجب هلكد تضحك😹",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "داني"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"قندره عليه عوفه خلي يؤلي😒😹",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "فايدر"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"ؤرده مال الله😻",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "سعد"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"😹عوفه هلزباله😹",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "🚶💔"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"شبيه كلبك حوبي😢",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "💔🚶"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"شبيه كلبك يرؤحي😢",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "شسمك"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"بنيه كول شسمج🙈😻",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "بوت"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"ومرض😒شرايد😹",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "بمكن علاقه"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"دي😹سؤي ؤيه خالتك ",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "حبيتك"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"شنو من اول رد حبيتني😹😹",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "مشتاقلك"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"انته ليش اجذب؟😹",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "مشتاقلج"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"😹بدء الزحف😹",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "شكد عمرك"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"اسف مرتبط😹",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "🙄"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"عدل عيؤنك لصير احول😐",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "هلو باي"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"شحسيت من هيج كتبت😹",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "خره"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" بـحـلكڪ😒💦 ",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "نعال"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" اخلاقك حبي😹😻",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "تعال"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" وين اجي😕 ",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "السلام عليكم"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" وعليكم السلام ورحمه حته الله😒😹 ",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "مساء الخير"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" مساء النؤر حياتي ",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "صباح الخير"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" صباح الؤرد🙈 ",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "باي"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" سلمنه ع اهلك كلهم😹 ",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "تصبحون ع خير"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" وانته من اهلو ",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "هاي"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" هايات يرؤحي🙈😻",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "احم"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" اسـم الله😧اشربـ/ي دوة😓 ",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "وينك"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" موجود حبي☺️",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "اكلك"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" لتكول تره صطرتنه😹",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "اتفل"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" خووووختف💦💦",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "اموت عليك"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" 😻me to love🙈",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "شكو"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" لتدخل بما لا يعنيك😹🐸",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "اكلكم"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"😹لتكول😹",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "اوف"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" سلامتك من ال اوف",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "شونك"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" ع خودا😹 وانته",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "احجي عربي"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" لك بابا العربي ميرادله شي بس اقراه انكليزي😹",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "💔"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" ع شنو مكسؤر قلبك😒",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "تسلم"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" عياتو ولو😹🙈",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "شكرا"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" ولو😹",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "اجه العيد"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"😹 لعد متسبح😹",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "😡"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" يممه هدي اعصابك هديهه😹اهم شي صحتك😹",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "🌺"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" وانته عطرهه😻❤️",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "🐸"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" ساحف😹",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "😴"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" متولي تنام لعد😒😹",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "👳‍♀️"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" استر علينه شيخ😹😹",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "🤔"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" 😹بشنو دتفكر 😕",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "💦"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" بوجهك ياكلب بن الكلب",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "🤓"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" شدتحس😜",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "😏"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" عدل حلكك يول😂",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "انته بتحبني"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" 😹ولله ما ادري بس افكر😕",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "خاص"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" اجي وياكم😻",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "تكرهني"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"موووووت",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "اضحك"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"هههههههههههههه",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "ابجي"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"اهئ اهئ اهئ اهئ",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "من وين"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"بغداد",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "ع راسي"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"سالم راسك",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "فدوه"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"لخشمك يرؤحي",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "شنو احسن مسرح"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"كرياتين ووويلي يخبل",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "كرياتين"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"يخبل احسن نوعيه للشعر",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "موهير"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"يخلونه ما بعد الكرياتين حته الشعر يخبل يصير وسرح ولمعه بي ",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "عسل"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" مثلك😻",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "فديتك"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" فداك الي بالي😻",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "منو بالك"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" عباس ابو الغاز شبيك😻",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "استغفرلله"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" بركاتك مولاي♡♥️",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "راح اكفر"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"اشك حلكك اذا اسؤيهه",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "مداك"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" اجاوزك بسرعتي امري لله😻",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "امك شلونهه"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"مو البارحه جانت يم امك",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "ابوك شلونه"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" الحمدلله بخير😻",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "ها"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"ولطما الي تلطمك",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "اكلج"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"داحسك دتزحف",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "تخليني"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" وانته وين عدك😻",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "مطي"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" حسن اخلاقك حب",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "نعل"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" بحلكك كبد",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "اموري"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" العشق♡♥️",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "ضرغام"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"الغالي مالي♡♥️",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "بخير"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" عساك دوم انشالله",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "ليش احبك"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"♥️لان انته عشقي♥️",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "ليش اكرهك"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" لان ما احترمك😻",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "ضيف جديد"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"*اهلا وسهلا~♡",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "هلوو"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" يممممه هلا ب نبضي♡♥️😻",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "احبج"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" وليحب بلوه وين الله وقسمتي ترؤح يم عيؤؤنج الحلوه",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "شكد تحبني"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" بكد هوه الله بكد الكائنات",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "موال"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"☝🏿شكولي مال تحشيش ماخربها بلموال 😹❤️",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "صاكه"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" وينها خلي اكفش شعرها 😹😍 ",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "عشق"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" يمه اذوبــن 😌❤️ ",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "مرتي"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" يمه اذوبــن ♡♥️",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "ملابس"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" 🌚☝🏿 تريدهن من المول لو من باله ؟ ",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "مول"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" 😹☝🏿يريد يقطني ماشتريلك لوتموت ",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "باله"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" 😹☝🏿 موحلوات عليك هم ماشتريلك
",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "اشو ماكو احد"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"موجودين حياتي-_-♥️",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "بعدك لو بطلت"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"بربك اكو واحد يعوف شغله -_-",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "ديي"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"انته اكبر زربه وبطل هاي اخلاقك زباله",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "اشو مختفي"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"وين مختفي بنلخرا غير موجود-_-",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "علو"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"اول شي كولهه عدل؟ثاني شي احجي",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "روجي"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"ولك هاذا واحد سافل وسخيف لتحجي وياهه نصيحه مني ولله ع مودك -_-",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "😐💔"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"شبيك كال خلقتك",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "حبك"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"اعشقك يروح الروح",
'reply_to_message_id'=>$message->message_id, 
]);
} 
if($text == "اكرهك"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"بس مو بكدي ههه",
'reply_to_message_id'=>$message->message_id, 
]);
} 
if($text == "ممكن نتعرف"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"لا اسف مرتبط  ",
'reply_to_message_id'=>$message->message_id, 
]);
} 
if($text == "😴"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"ولي نام اذا هيج نعسان😹😹",
'reply_to_message_id'=>$message->message_id, 
]);
} 
if($text == "🙄"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"باوع عدل مطي😹😕",
'reply_to_message_id'=>$message->message_id, 
]);
} 
if($text == "حبيتج"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"لي اجذب انته وشبسرعه حبيتهه بن الزاحف😹😹",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "غنيلي"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"صوتي خره مو مال اغاني",
'reply_to_message_id'=>$message->message_id, 
]);
} 
if($text == "بوسني"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"ٲٳمٌـۧ﴿🌝💋﴾ـۛويِّحًهٍہ💕⇣ֆ ",
'reply_to_message_id'=>$message->message_id, 
]);
} 
if($text == "بوسه قويه"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"ٲٳمٌممممممممممممممممممـۧ﴿🌝💋﴾ـۛويِّحًهٍہ💕⇣ֆ ",
'reply_to_message_id'=>$message->message_id, 
]);
} 
if($text == "تحب روجي"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"لاع خلي ولي وصخ😹",
'reply_to_message_id'=>$message->message_id, 
]);
} 
if($text == "شغل ضوه"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"ميحتاج اشغله هوه انته شمعه ",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "علي المنصوري"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"الدنيا وش الدنيا لو شح الحبيب وويلي😍😍",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "اني منو"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"شمدريني متكلي تره اني بوت مو شخص 😹😕",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "ضوجه"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"ولي اطلع شعليه اني جاي يمي تكول ضوجه😹😐",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "تحبيني"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"ها بده الزحف مو😹😕",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "شغل مولده"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"بانزين مابيهه ولي جيب واشغلهه ",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "جبت بانزين"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"تدلل هسه اشغله بس لم من كل عضو الف مال بانزين😹😹",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "ايفون"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"وويلي كون عدي بس ولو زباله يرادله ايتونز😹😕",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "شكد متابعينج"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"مليارات قابل مثلك فاشل",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "اشكرك"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"ولو😍😹",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "شغل ثلاجه"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"شغلتهه ولدزني بعد تريد كوم انته فتهمت😡😹 ",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "شغل بلازما"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"تعبت ولرب كوم انته فدوه😹😻😻",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "شغل المروحه"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"😻شغلتهه استادي🙈😻",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "رتب الكروب راح يجي خطار"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"رتبته من الصبح كعدت ب 6😹😹🙈",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "🙈"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"عود يستحي وجه القرد الوصخ😹😹😹",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "زباله"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"لشبهني بيك فدوه",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "شسمج"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"✧ دّلّـﮩﮧـؤٰ୭شـۿﮧّ😻🌸 ℡",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "نعال"  ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=> " بـﮩـوجـهـڪ 😐😂" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text == "حروح اسبح"  ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>" واخيراً 😹🌝"  ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "حروح اغسل" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>" واخيراً 😹🌝"  ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==   "حروح اطب للحمام" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>" واخيراً 😹🌝"  ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==   "حبيبتي" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>" منو هاي 😱 تخوني 😔☹️"  ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "كبلت" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>" بلخير 😂💔" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text == "البوت عاوي" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>" اطردك ؟ 😒"  ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "منور" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=> " بـﮩـنورك حـﮩـبـﮩـي 😍🍷"  ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text == "حفلش"  ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=> " افلش راسك"  ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text == "كردي"  ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=> "والنعم منك ❤️" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text == "🌝"  ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"مــﮩﮩﮩــننوورر 🌝💙" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==   "حلو" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=> "ٱنـﮩـت الاحـلآ 🌚❤️"  ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==   "😑" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>" شبيك 🍃☹️"  ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "😒" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"شِـبـيک کآڵـب وجـهہهـڪ 😐"  ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "منو تحب" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=> "خـﮩـالـتڪ ٱلـشـڪـرﮪ 😹🏃🏻"  ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==    "مضغوط" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=> "دي انضغظ منك ؟ 😂😂"   ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==   "فديتج"  ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>   "ها  زاحف كمشتك"  ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "شوف خاصك"  ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=> "شدازله 😱😨"   ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "تعال خاص"  ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>  "شحسوون 😱"   ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "😎"  ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>    "يلا عود انته فد نعال 😐🍃" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "😱" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=> "خير خوفتني 😨"   ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "كحبه"  ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>  "عيب 😱"  ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==   "بيش ساعة" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=> "ما اعرف 🌚🍃"  ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text == "🚶🏻"   ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>  "لُـﮩـضڵ تتـمشـﮥ اڪعـد ﺳـﯠڵـف 😐👋🏻"  ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "ليش"  ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=> "تاكل خرة الجيش 😂😂"  ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==   "عشرين"  ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=> "تاكل جدر خنين 😫"   ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "طار"  ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"ابن الطيار"    ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==   "لتزحف" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>  "وك اسف 🙁😔"   ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==   "حاته"  ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>  "زاحف 😂 منو هاي دزلي صورتهه"  ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "صاكه" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>  "زاحف 😂 منو هاي دزلي صورتهه"  ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "صاك" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=> "زاحفه 😂 منو هذا دزيلي صورهه"   ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "منو اني"  ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>   "انته احلى شي بحياتي ❤️🍃" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==   "ابن الكلب"  ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>  "عيب ابني 🔥☹️"  ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==    "انجب انته"  ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>   "وك وك 😭😔"  ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "حطردك"   ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>    "اعصابك 😨 لتتهور" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==    "منو اموري"  ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"هذا المطور مالتي   ❤️🙈"   ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==   "منو اكثر واحد تكرهه"  ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=> "انته"   ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "شباب"   ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"هًّـــُ﴿⍨﴾ـٍِـــہاا حـﮩـب 🚶🏻🌝"    ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==    "انته زلمه"  ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>   "تعال لزمه 😐😂"  ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==   "هلاوو"   ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=> "هـﮩـڵآوآت 🦀❤️"   ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==     "اختك" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>   "شبيهه 😱"  ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==    "كواد"  ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>   "عيب 😨😨" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "😌"   ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>  "ٱڵـمـطـڵـوب ¿ ❥"  ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "هلا"   ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>   "✾  هـﮩـڵا ہبـﮩـک 💙🖐🏻"  ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "هلوووو"   ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>  "✾  هلااا نوررررررت💙🖐🏻" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text == "ضوجه"  ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=> "و المطلوب شنو اركصلك/ج مثلا 🙊😋" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "دير بالك عليهم" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"😉😍تأَمَرنَي أَمر حَبِيبَ كلبَيِ تَشلعَ عينَيَ" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==   "اني" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=> "انت لو بس تنجب جا هسه اموري كلهه تمام😂😘",
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "كلخره" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>  " حط نفسك بماعون😌😒",
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "كلخرا"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>  " حط نفسك بماعون😌😒",
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "😕"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"عـــاوج حلكَك عليمــن 🌝"  ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==   "صخام"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=> "😡بــوجــهــك😏مـلـطــلط😒",
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "بنيه" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"😏واذا بــنــيــه🌚 مـــا تشـــوفــيـن😒 شــون الله مطـيــح حظج😈"  ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "انت ياهو يمك"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=> "😏كــبــر🌚 را ســـك😒 وكـامــت تتعيقل علي😈" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "نعلبوك" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=> "انجب حشري🍃😹" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text == "هههه" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=> "😘❤️دووووم ❤️الضحكه 😂🙈",
'reply_to_message_id'=>$message->message_id,
]);
}
if($text == "😳" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>  "🌚شـبــيــك😒مصـــدوم🌝حبي شنو جديده عليك ها حتى تنصدم" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==   "اندعيلي" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"الله ينطيك" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "ها"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"وجعا اشبيك الفاهي🌚" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==   "وينك" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=> "هياتني😅😼" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "وينج"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=> "هياتني😅😼" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==   "انته وين"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=> "يم خالتك🌝" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "وين" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"عوفه ضايج خل يطلع يغير جو لطشت عليه😳😹😹"  ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "بوسه" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"امــہـ😘😚😘😚😘ــہــواااااح" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "طن"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=> "طنات🌝" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==   "اتفلي"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=> "اتفل عليك😼🌝" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==   "تعال" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"اوكف انطي مجال😳☹️لك شوف الحاتات دوخني😚"  ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "شلونج" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"الحمدلله وانته" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==   "سني"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"لتصير طائفي 😒🖐" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "شيعي"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"لتصير طائفي 😒🖐" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text == "😍" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=> " مح فديتك" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text == "مح"  ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=> " فوديتك❤️",
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "😭"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>  " 😢😢 لتبجي حبي محد يفيدك/ج",
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==   " 😢"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>  " 😢😢 لتبجي حبي محد يفيدك/ج",
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "شكد عمرج"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>" زاحف 😂" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "منو حبيبج" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"قاسم واموري" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text == "دي" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"يمشوك بيها 🌝" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "كعدي بحضن اموري"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>" ايي طبعا غير حبيبي" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "تكرهني"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"اي اكرهك اموت منك😛" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "اكرهج"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=> " علساس اني احبك تهي بهي 😒🍃",
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "😇" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"  اته مو ملاك اته جهنم بنفسهه 😂" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "😐" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=> " شبيك صافن 😒🔥" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "حاره"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"يي تجوي😭🍃🔥" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "انتي حبيبت منو"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=> "حبيبت اموري",
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "🙂"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=> "عود ثكيل ؟ 😪",
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "🙃"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=> "عود ثكيل ؟ 😪",
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "شدتحس" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>" داحس بيك" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "اكولك"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"كول وماكول لاحد 🙊💓" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "اكلك"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"كول وماكول لاحد 🙊💓" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==   "منو ضلع اموري" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>" غـﮧـّ̐ہٰٰﮧ✥ٍُـّ̐ہٰٰيہٰ۫ـ❈ـّ̐ہٰٰــ๋͜ہٌۤـہٰٰﮧ௸ْْـّ̐ہٰٰث❤️" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text == "باي"  ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>" بايات ❤️🍃",
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "تنحي"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=> "عيب ابني 😒🍃",
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "خاينة"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"دي زباله ما اخون اني" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "جوعان"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"تعال اكلني 😐😂" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "عطشان" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"روح اشرب مي" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==   "🙁"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"لضوج حبيبي 😢❤️🍃" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==   "😔"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>" ليش الحلو ضايج ❤️🍃" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "🌚" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"منور صخام الجدر 😹☝️" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==   "ما احبج"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"😍 ديي طبك مرض" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text ==  "بغداد" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"😍 فديتهه" ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text == "دلوشه" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"😘 يـآ بَـعد ❤️ روَوح  😚 دلوشه 😻  \n " ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text == "شلونج" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"😘 بخير يابعد اختك ❤️😍😻  \n " ,

'reply_to_message_id'=>$message->message_id,
]);
}
if($text == "خاينه" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"😘 كلخرا حبي الغالي ❤️😍😻  \n " ,

'reply_to_message_id'=>$message->message_id,
]);
}
if($text == "انجبي" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"😘 اخلاقك/ج ❤️😍😻  \n " ,

'reply_to_message_id'=>$message->message_id,
]);
}
if($text == "نورتي" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"😘 نورك/ج رؤيحتي ❤️😍😻  \n " ,

'reply_to_message_id'=>$message->message_id,
]);
}
if($text == "تمام وانتي" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"😘 بخير عافيتي❤️😍😻  \n " ,
'reply_to_message_id'=>$message->message_id,
]);
}
if($text == "غادري"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"تم المغادره اصنع بوتك الخاص🔧 @DS_DS18BOT",
]);
bot('leaveChat',[
'chat_id'=>$chat_id
]);
}
if($text == "/id"){
bot('sendmessage',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>" *Your Name 🎶* :* $name *
*اصنع بوتك الخاص 🔧*:*  @DS_DS18BOT *",
'parse_mode'=>"MARKDOWN",
'reply_markup'=>json_encode([
      'inline_keyboard'=>[
[
['text'=>"اصنع بوتك الخاص🔧" ,'url'=>"https://t.me/DS_DS18BOT"]
],
]
])
]);
}
if($new_member){ 
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'message_id'=>$message->message_id, 
'text'=>"<b>نووووورت المجموعه  ⚜️🌬</b> 
<b>ووووردايه ➖💎</b>  
<b>التزم بقوانين المجموعه 🔉</b>",
'parse_mode'=>"html", 
'reply_to_message_id'=>$message->message_id,
]); 
} 
if($left){ 
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'message_id'=>$message->message_id, 
'text'=>"<b>اللللللللله االللللله وياك  سلمنه ع اهل😹😹 🙃💥</b>", 
'reply_to_message_id'=>$message->message_id,
'parse_mode'=>"html", 
]); 
}
$sudo = $message->from->id; 
$deve = $get_token[1];
if($text=="حذف صوره الكروب"&& $sudo == $deve){
bot('deleteChatPhoto',[ 
'chat_id'=>$chat_id,
]);
}
if($re && $text == "ايدي"){
bot('sendmessage', [
'chat_id' => $chat_id,
'text' => "id = $re_id
name = $re_name
user = $re_user",
]);
}
if($text == "المطور"){
 bot('sendMessage',[
  'chat_id'=>$chat_id,
  'text'=>"*#️⃣Developer 🎶*",
'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
      'inline_keyboard'=>[
          [
              ['text'=>"اصنع بوتك الخاص🔧", 'callback_data'=>"keyboard"],
              ['text'=>"@DS_DS18BOT", 'url'=>"https://t.me/DS_DS18BOT"],
          ],
          ]
      ])
  ]);
}
if($text == "معلوماتي" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'parse_mode'=>'MarkDown',
'disable_web_page_preview'=>true,
"text"=>" اســمــك 🔱◀️ : $name 
 يوزرك 🌐 ◀️  : @$username
 ايديك ⚜️ ◀️ : $id, [$name](https://t.me/$username)  ",
'message_id'=>$message->message_id,
'reply_markup'=>json_encode([
      'inline_keyboard'=>[
        [['text'=>'اصنع بوتك الخاص🔧', 'url'=>"https://t.me/DS_DS18BOT"]],
]
])
]);
}
if($text =="الوقت"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"🇮🇶 البلد : العراق \n" . "❣️  السنة : " . date("Y") . "\n" . "🗓  الشهر : " . date("n") . "\n" . "💫  اليوم :" . date("j") . "\n" . "⏰ الساعه :" . date('g', $time) . "\n" . "⌚️ الدقيقه :" . date('i', $time) . "\n" . " ❣️",
'reply_to_message_id'=>$message->message_id
]);
}
$sudo = $message->from->id; 
$deve = $get_token[1]; 
$rep = $message->reply_to_message; 
$rep_msg = $rep->message_id; 
if($rep && $text=="تثبيت" && $sudo == $deve){
bot('pinChatMessage',[
'chat_id'=>$chat_id,
'message_id'=>$rep_msg
]);
}
if($text== 'عدد المشتركين'){
bot('sendMessage' ,[
'chat_id'=>$chat_id,
'text'=>$count,
'reply_to_message_id'=>$message->message_id
]);
}
if($textmsg == "قفل التوجيه" && !is_dir("mute")){
 mkdir("mute");
   bot('sendmessage',[
   'chat_id'=>$chat_id,
    'message_id'=>$message_id,
   'text'=>"🚫➖➖➖➖🔒➖➖➖➖🚫

تـޢޢـم قـޢޢـفـޢޢـل آعـޢޢـآده تـޢـۅجيه🔒❗️ 
🚫➖➖➖➖🔒➖➖➖➖🚫",
'reply_to_message_id'=>$message->message_id,
        ]);
         }
if($textmsg == "فتح التوجيه" && is_dir(mute)){
  rmdir("mute");
bot('sendmessage',[
   'chat_id'=>$chat_id,
    'message_id'=>$message_id,
   'text'=>"✅➖➖➖➖🔐➖➖➖➖✅

تـޢޢـم فـޢޢـتـޢޢـح آعـޢޢـآده تـޢـۅجيه🔓🔑  
✅➖➖➖➖🔐➖➖➖➖✅",
'reply_to_message_id'=>$message->message_id,
        ]);
         }
if($message->forward_from && is_dir("mute")){
 bot('deletemessage',[
'chat_id'=>$chat_id,
'message_id'=>$message_id
]);
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"عہہزيہزي لا ادز  اعہٰٰٰ۫ہٰاده تہٰٰٰ۫ہ۫ؤ۫جيه لاﮩ'ٰۗٛۧۙۙ  ابہو:گ اشعله'ٰۗٛۧۙۙﮩ'ٰۗٛۧۙ🚫💣  $name \n معرفك @$username"
]);
}
elseif($text == "صوره اموري"){
 bot('sendphoto',[
 'chat_id'=>$chat_id,
 'photo'=>"https://www.facebook.com/photo.php?fbid=144461112770951&set=a.102118047005258.1073741826.100016211883906&type=3&theater",
 'caption'=>"تفضل هاي صؤرته",
'reply_to_message_id'=>$message->message_id, 
]);
 }
elseif($text == "صوره صرنه مكروهين"){
 bot('sendphoto',[
 'chat_id'=>$chat_id,
 'photo'=>"https://www.facebook.com/photo.php?fbid=134141997136196&set=a.102118257005237.1073741827.100016211883906&type=3&theater",
 'caption'=>"صرنه مكرؤهين",
'reply_to_message_id'=>$message->message_id, 
]);
 }
if($textmsg == "قفل الصور" && !is_dir("mute")){
 mkdir("mute");
   bot('sendmessage',[
   'chat_id'=>$chat_id,
    'message_id'=>$message_id,
   'text'=>"🚫➖➖➖➖🔒➖➖➖➖🚫

تـޢޢـم قـޢޢـفـޢޢـل الـޢصور 🔒❗️ 
🚫➖➖➖➖🔒➖➖➖➖🚫",
'reply_to_message_id'=>$message->message_id,
        ]);
         }
if($textmsg == "فتح الصور" && is_dir(mute)){
  rmdir("mute");
bot('sendmessage',[
   'chat_id'=>$chat_id,
    'message_id'=>$message_id,
   'text'=>"✅➖➖➖➖🔐➖➖➖➖✅

تـޢޢـم فـޢޢـتـޢޢـح الޢصޢور🔓🔑  
✅➖➖➖➖🔐➖➖➖➖✅",
'reply_to_message_id'=>$message->message_id,
        ]);
         }
if($message->photo && is_dir("mute")){
 bot('deletemessage',[
'chat_id'=>$chat_id,
'message_id'=>$message_id
]);
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"عزيزي ممنوع الصور تم قفلها🚫💣  $name \n معرفك @$username"
]);
}
if($textmsg == "قفل البصمات" && !is_dir("mute")){
 mkdir("mute");
   bot('sendmessage',[
   'chat_id'=>$chat_id,
    'message_id'=>$message_id,
   'text'=>"🚫➖➖➖➖🔒➖➖➖➖🚫

تـޢޢـم قـޢޢـفـޢޢـل الـޢبصمات 🔒❗️ 
🚫➖➖➖➖🔒➖➖➖➖🚫",
'reply_to_message_id'=>$message->message_id,
        ]);
         }
if($textmsg == "فتح البصمات" && is_dir(mute)){
  rmdir("mute");
bot('sendmessage',[
   'chat_id'=>$chat_id,
    'message_id'=>$message_id,
   'text'=>"✅➖➖➖➖🔐➖➖➖➖✅

تـޢޢـم فـޢޢـتـޢޢـح الޢبصمات🔓🔑  
✅➖➖➖➖🔐➖➖➖➖✅",
'reply_to_message_id'=>$message->message_id,
        ]);
         }
if($message->voice && is_dir("mute")){
 bot('deletemessage',[
'chat_id'=>$chat_id,
'message_id'=>$message_id
]);
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"ممنوع البصمات عزيزي🚫💣  $name \n معرفك @$username"
]);
}
if($textmsg == "قفل الفيديو" && !is_dir("mute")){
 mkdir("mute");
   bot('sendmessage',[
   'chat_id'=>$chat_id,
    'message_id'=>$message_id,
   'text'=>"🚫➖➖➖➖🔒➖➖➖➖🚫

تـޢޢـم قـޢޢـفـޢޢـل الـޢفيديو 🔒❗️ 
🚫➖➖➖➖🔒➖➖➖➖🚫",
'reply_to_message_id'=>$message->message_id,
        ]);
         }
if($textmsg == "فتح الفيديو" && is_dir(mute)){
  rmdir("mute");
bot('sendmessage',[
   'chat_id'=>$chat_id,
    'message_id'=>$message_id,
   'text'=>"✅➖➖➖➖🔐➖➖➖➖✅
تـޢޢـم فـޢޢـتـޢޢـح الޢفيديو🔓🔑  
✅➖➖➖➖🔐➖➖➖➖✅",
'reply_to_message_id'=>$message->message_id,
        ]);
         }
if($message->video && is_dir("mute")){
 bot('deletemessage',[
'chat_id'=>$chat_id,
'message_id'=>$message_id
]);
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"ممنوع الفيديو عزيزي🚫💣  $name \n معرفك @$username"
]);
}
if($textmsg == "قفل الملصقات" && !is_dir("mute")){
 mkdir("mute");
   bot('sendmessage',[
   'chat_id'=>$chat_id,
    'message_id'=>$message_id,
   'text'=>"🚫➖➖➖➖🔒➖➖➖➖🚫

تـޢޢـم قـޢޢـفـޢޢـل الـملصقޢات 🔒❗️ 
🚫➖➖➖➖🔒➖➖➖➖🚫",
'reply_to_message_id'=>$message->message_id,
        ]);
         }
if($textmsg == "فتح الملصقات" && is_dir(mute)){
  rmdir("mute");
bot('sendmessage',[
   'chat_id'=>$chat_id,
    'message_id'=>$message_id,
   'text'=>"✅➖➖➖➖🔐➖➖➖➖✅
تـޢޢـم فـޢޢـتـޢޢـح الޢملصقات🔓🔑  
✅➖➖➖➖🔐➖➖➖➖✅",
'reply_to_message_id'=>$message->message_id,
        ]);
         }
if($message->sticker && is_dir("mute")){
 bot('deletemessage',[
'chat_id'=>$chat_id,
'message_id'=>$message_id
]);
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"ممنوع الملصقات انتبه عزيزي🚫💣  $name \n معرفك @$username"
]);
}
if($textmsg == "قفل جهات الاتصال" && !is_dir("mute")){
 mkdir("mute");
   bot('sendmessage',[
   'chat_id'=>$chat_id,
    'message_id'=>$message_id,
   'text'=>"🚫➖➖➖➖🔒➖➖➖➖🚫

تـޢޢـم قـޢޢـفـޢޢـل جهات الاتصال 🔒❗️ 
🚫➖➖➖➖🔒➖➖➖➖🚫",
'reply_to_message_id'=>$message->message_id,
        ]);
         }
if($textmsg == "فتح جهات الاتصال" && is_dir(mute)){
  rmdir("mute");
bot('sendmessage',[
   'chat_id'=>$chat_id,
    'message_id'=>$message_id,
   'text'=>"✅➖➖➖➖🔐➖➖➖➖✅
تـޢޢـم فـޢޢـتـޢޢـح جهات الاتصال🔓🔑  
✅➖➖➖➖🔐➖➖➖➖✅",
'reply_to_message_id'=>$message->message_id, 
       ]);
         }
if($message->contact && is_dir("mute")){
 bot('deletemessage',[
'chat_id'=>$chat_id,
'message_id'=>$message_id
]);
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"ممنوع عزيزي ارسال جهات الاتصال في المجموعه🚫💣  $name \n معرفك @$username"
]);
}
if($textmsg == "قفل الالعاب" && !is_dir("mute")){
 mkdir("mute");
   bot('sendmessage',[
   'chat_id'=>$chat_id,
    'message_id'=>$message_id,
   'text'=>"🚫➖➖➖➖🔒➖➖➖➖🚫

تـޢޢـم قـޢޢـفـޢޢـل الالعاب 🔒❗️ 
🚫➖➖➖➖🔒➖➖➖➖🚫",
'reply_to_message_id'=>$message->message_id,
        ]);
         }
if($textmsg == "فتح الالعاب" && is_dir(mute)){
  rmdir("mute");
bot('sendmessage',[
   'chat_id'=>$chat_id,
    'message_id'=>$message_id,
   'text'=>"✅➖➖➖➖🔐➖➖➖➖✅
تـޢޢـم فـޢޢـتـޢޢـح الالعاب🔓🔑  
✅➖➖➖➖🔐➖➖➖➖✅",
'reply_to_message_id'=>$message->message_id, 
       ]);
         }
if($message->game && is_dir("mute")){
 bot('deletemessage',[
'chat_id'=>$chat_id,
'message_id'=>$message_id
]);
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"ممنوع عزيزي الالعاب🚫💣  $name \n معرفك @$username"
]);
}
if($textmsg == "قفل الروابط" && !is_dir("mute")){
 mkdir("mute");
   bot('sendmessage',[
   'chat_id'=>$chat_id,
    'message_id'=>$message_id,
   'text'=>"🚫➖➖➖➖🔒➖➖➖➖🚫

تـޢޢـم قـޢޢـفـޢޢـل آلـޢޢروابطـ🔒❗️ 
🚫➖➖➖➖🔒➖➖➖➖🚫",
        ]);
         }
if($textmsg == "فتح الروابط" && is_dir(mute)){
  rmdir("mute");
bot('sendmessage',[
   'chat_id'=>$chat_id,
    'message_id'=>$message_id,
   'text'=>"✅➖➖➖➖🔐➖➖➖➖✅

تـޢޢـم فـޢޢـتـޢޢـح آلـޢޢروابطـ🔓🔑  
✅➖➖➖➖🔐➖➖➖➖✅",
        ]);
         }
if(preg_match('/^(.*)([Hh]ttp|[Hh]ttps|t.me)(.*)|([Hh]ttp|[Hh]ttps|t.me)(.*)|(.*)([Hh]ttp|[Hh]ttps|t.me)|(.*)[Tt]elegram.me(.*)|[Tt]elegram.me(.*)|(.*)[Tt]elegram.me|(.*)[Tt].me(.*)|[Tt].me(.*)|(.*)[Tt].me/',$text) ){
bot('deleteMessage',[
'chat_id'=>$chat_id,
'message_id'=>$message->message_id
  ]);
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"عہہزيہزي لا ادز  روابط لاﮩ'ٰۗ  ابہو:گ اشعله'ٰۗﮩ'ٰۗ🚫💣  $name \n معرفك @$username"
]);
}