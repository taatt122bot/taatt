<?php

//تم نشر ملف بوت االمصنع بسبب هذا االفرخ @xxi10 روحو لعنده قولوله كسمك

//@SyriaAndroid //@DS_DS
#----ابـৡـن_الـৡـدولـৡـۂ_الـৡـادلـৡـبـৡـيـৡـۂ----#

$get_toke = file_get_contents('info.txt');

$get_token = explode("\n", $get_toke);


$url_info = file_get_contents("https://api.telegram.org/bot$get_token[0]/getMe");

$json_info = json_decode($url_info);

$user = $json_info->result->username;

$bot_id = $json_info->result->id;

$admin = $get_token[1];

ob_start();

$API_KEY = $get_token[0];
define('API_KEY',$API_KEY);
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$text = $message->text; 
$admin = 361666730;
$data = $update->callback_query->data;
$chat_id2 = $update->callback_query->message->chat->id;
$message_id2 = $update->callback_query->message->message_id;

$name = $message->from->first_name;
$username = $message->from->username;

$u = explode("\n",file_get_contents("data/memb.txt"));
$c = count($u)-1;
if ($update && !in_array($chat_id, $u)) {
    file_put_contents("data/memb.txt", $chat_id."\n",FILE_APPEND);
  }
  if ($text == '/mem' and $chat_id == 361666730) {
    bot('sendMessage',[
      'chat_id'=>$chat_id,
      'text'=>"مستخدمين البوت 🤖 الخاص بك :- $c"
    ]);
  }

$id = $message->from->id;
$abood = file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=@SyriaAndroid&user_id=$id");
if($text == "/start" and strpos($abood, '"status":"left"') == TRUE){
mkdir("data");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"عذراََ !⚠️
يجب الاشتراك في قناة البوت .📡 اولاََ 
بعد الاشتراك ارسل /start",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"اضغط هنا للأشتراك", 'url'=>"https://telegram.me/joinchat/AAAAAEPjXnTHQvDNr_dQgw"]]    
]    
])
]);
}
$wel = file_get_contents("data/start.txt");
if ($text == "/start" and strpos($abood, '"status":"left"') != TRUE){
    bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>"❤️┋اهلا بك في بوت الردود المتطور
 
💛┋البوت الاول على تيليجرام في هذه الميزات

💚┋اذا كنت ترغب في اضافت البوت الى مجموعتك فقط عليك

💙┋رفع البوت ادمن في مجموعتك


🎃┋ميزة البوت

💡┋ميزة اضف رد الجديدة #مثال
اضف هلو
هلوات حبي💖

💥┋البوت سريع جدا في الاستجابة
🎭┋ نوع ردوده /كتابة مزغرفة
🛠┋سيتم قريبا اضافة ردود بصمات بنات

اذا كنت تحتاج لـ مساعدة ⚙ 
 📝🎈
راسل مبرمج البوت 👨‍💻
@DS_DS
",
        'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>"🔧اصنع بوتك الآن🔧💡",'url'=>"https://telegram.me/DS_DS18BOT?start"]],
            ]
        ])
        ]);
}
// فقط كود الاذاعه ماخذه من ملف
$about = file_get_contents("data/about.txt");

$admin = 361666730; // your id ;
if($text == "/helpsaeed" and $chat_id == $admin){
    bot('sendMessage',[
    'chat_id'=>$chat_id,
    'text'=>"اهلا بك #مطوري

في قائمه الاوامر 📍

اضغط ع المشتركين 💐

لعرض عدد مشتركين ⌛️

و الامر الثاني 🔮

لـ الاذاعه 📥",
    'reply_markup'=>json_encode([
        'inline_keyboard'=>[
              [['text'=>"عدد الكروبات والمشتركين📅",'callback_data'=>"count"]],
            [['text'=>"ارسال رسالة للكل 🔂",'callback_data'=>"send_all"]],
        ]
    ])
    ]);
}
if($data == "count" and $chat_id2 == $admin){ //مشتركين البوت = مهمة 1
    bot('answercallbackquery',[
        'callback_query_id'=>$update->callback_query->id,
        'text'=>"عدد كروبات البوت📬 : $c",
        'show_alert'=>true,
]);
}
 
$mode = file_get_contents("data/mode.txt");
if($data == "send_all" and $chat_id2 == $admin){
    file_put_contents("data/mode.txt","yas");
    bot('EditMessageText',[
    'chat_id'=>$chat_id2,
    'message_id'=>$message_id2,
    'text'=>"ارسل رسالتك الان 📩 وسيتم نشرها لـ $c كروب وسيتم ارساله للمشتركين في البوت . 
    - تستطيع التراجع بالضغط على الغاء . ",
    'reply_markup'=>json_encode([
        'inline_keyboard'=>[
            [['text'=>"الغاء🚫",'callback_data'=>"off"]],
        ]
    ])
    ]);
}
if($text and $mode == "yas" and $chat_id == $admin){
    for ($i=0; $i < count($u); $i++) { 
        bot('sendMessage',[
          'chat_id'=>$u[$i],
          'text'=>"$text",
        ]);
}
} 
if($data == "off"){
    file_put_contents("data/mode.txt","no");
    bot('EditMessageText',[
    'chat_id'=>$chat_id2,
    'message_id'=>$message_id2,
    'text'=>"اهلا بك #مطوري

في قائمه الاوامر 📍

اضغط ع المشتركين 💐

لعرض عدد مشتركين ⌛️

و الامر الثاني 🔮

لـ الاذاعه 📥",
    'reply_markup'=>json_encode([
        'inline_keyboard'=>[
             [['text'=>"عدد الكروبات والمشتركبن📅",'callback_data'=>"count"]],
            [['text'=>"ارسال رسالة للكل 🔂",'callback_data'=>"send_all"]],
        ]
    ])
    ]);
}
$rdod = json_decode(file_get_contents("rep.json"),true);
if(preg_match('/^(اضف)(.*)/',$text)){
 $text = str_replace('اضف ','',$text);
 $text = explode("\n",$text);
 bot('sendMessage',[
    'chat_id'=>$chat_id,
    'text'=>"تم اضافة الرد بنجاح ❤️✔️"
 ]);
$rdod[$text[0]] = $text[1]; file_put_contents('rep.json',json_encode($rdod));
}
foreach($rdod as $key => $val){
 if($text == $key){
   bot('sendMessage',[
    'chat_id'=>$chat_id,
    'text'=>$rdod[$key]
 ]);
 }
}
$MATHEO = explode('قول',$text);
if($MATHEO){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>$MATHEO[1],
]);
}
if($text == "هلو" or $text == "هلوو" or $text == "هلووو"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"ُهـ♥ـلُـ😍ـوَااتْ نَـ😊ـوَرَتْ حُـ😘ـبّـيَ",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "مرحبا" or $text == "مرحباا"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"🌝םـــرحبتين 😍منــور/ه ",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "كيفكم" or $text == "شلونكم"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"بـّخـْيرٌ دامـّگ بـْخـّيرٌ يـّٱلـّغـٌالـّے❤️ أٌنــُتَ/ي ڳُــــيّفُڳً  ",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "ممكن" or $text == "ممكن سؤال"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"تُفَـــــ💖ٌــــضْل",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "انا بنت" or $text == "اني بنت"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"«أإ؏ــِّـْشٍّـٌ﴿😘 ﴾ــَّقـُكِ »انا ",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "سلام" or $text == "السلام عليكم"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"وَْعـ😘ـلُـيَـكِـمٌ الُـسِـ💖ـلُامٌ نَـوَرَتْـ/يَ حُـبّ😘ـيَ",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "حياكم" or $text == "حياك"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"َحُـــ☂ــياڪ/يَ تْــ🙈ـفَـضُـلُ/يَ ❤",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "مين" or $text == "مين انت"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"🙈❤️انا بّـوَتـْ وَأحـُبّـكِ ",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "كيفك" or $text == "اخبارك"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"تْـمٌـامٌـ مٌـا دِا❤مٌـكِ بّـٌخـيَـرَ",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "هههههه" or $text == "ههههههه" or $text == "ههه" or $text == "هههه" or $text == "ههههه"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"..✿دِْۈۈ↝يِـًِ☝ـٍآٍرٍبُ↝ۈۈم✿",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "😕" or $text == "☹️"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"ايـﺸ صار لحبيبي زعلاﻧ. اםـــۅۅوت ولا اشوفه زعلان خلاص ارضيك 😉",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "خاص" or $text == "تعالي خاص" or $text == "تعال خاص"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"ممنـــــ 🙊ــو؏الـخـــ💒ــاص الخاص لا تكون زاحـف 🌚😹",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "والله" or $text == "واالله"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"لا تحلف مصدقك من غير يمين اذا قلت بكره رمضان رح اصــوم 🌚😹",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "عندك قناة" or $text == "معك قناة" or $text == "عندك قناه" or $text == "معك قناه"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"ايــه معي احلا۽ قناة @SyriaAndroid شوف منشوراته 😍",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "تعال" or $text == "تعاال"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"وين نروووح الدنـــيا۽ تعبنا منها 😔💔",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "تعالي" or $text == "تعاالي"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"وين بتروحو وتسيبونا هنا 😕💔",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "😢" or $text == "😔"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"مبين عليك انك مقهور من الحــب 🌚😹",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "😍" or $text == "😍"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"مبين انڮ تـﺢـب يا بـﺦـت قلبك 🙊❤️",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "انا" or $text == "اناا"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"اعـۅوذ بالله םـن گلمت انا 🌚",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "اني" or $text == "انيي"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"انتي ايش 🙊",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "حلووه" or $text == "حلوه"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>" 😍والله ",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "بوت" or $text == "بووت"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"نَـْعـمٌ شِـوَ بّـتـ😔ْـرَيَـدِ حُـلُ ْعـنَـيَ😣",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "شو" or $text == "شوو"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"مابعرف😕💔تعال نفكر انا وانت",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "صلو على النبي" or $text == "صلو ع النبي"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"اللهم صلي وسلم وبارك على سيدنا ونبينا محمد😘❤️",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "مين انت" or $text == "مين انتي"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"انا بوت ردود اساعد الكروبات على التفاعل المستمر انصح ان تستعملني بحروبك 🙊❤️",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "بحبك" or $text == "احبك"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"ونا كمان 🙊احبـك وموت 🌚❤️",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "تبادل" or $text == "تبادلي"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
 text =>"انت متهلك 😒 ممنوع التبادل هنا 🌚💔",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "مين عنده جروب" or $text == "مين عنده جروب ثاني" or $text == "مين عندك كروب" or $text == "مين عندك كروب ثاني"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"ليش وهذا ماعجبك يعني 😕💔",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "بوت" or $text == "بووت"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"شبيك لبيك البوت بين يديك 😍❤️ بس لا تكثر منشان ما اعوفك وكرهك🌚💔",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "لا اله الا الله " or $text == "لا اله الا الله"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
 text =>"محمد رسول الله صلو عليه 💥🕊",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "بنات" or $text == "بنات"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"ايش تشتي البنات 🌚😹 مو عاجبينك العيال ياخروف 🐑",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "بنت" or $text == "بنت"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"لا تقول بنت قول مزه 😍😹",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "😂😂😂😂" or $text == "😂😂😂😂😂" or $text == "😂😂😂" or $text == "😂😂" or $text == "😂"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
 text =>"تــــــدوووووم 🌚💔",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "🌚😹" or $text == "😹🌚"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"لا تستحقر قبل ما ازعلك 🌚💔",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "😹😹😹" or $text == "😹😹😹😹" or $text == "😹" or $text == "😹😹" or $text == "😹😹😹"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"هذي ضحكتي المفضله وحبه ❤️ وحب من يضحكها 🙊❤️😹🌚",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "باي" or $text == "بااي"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"الله معك لا تورينا وجهك مره ثاني 🌚😹 امزح امزح الله معك انتبه من السيارات عدنا احبك 🙈❤️",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "وينك" or $text == "وينك"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"هون مارحت مكان لا تسوي نفسك تحبنا 🌚💔😹",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "اصه" or $text == "اصهه"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"لاصي يقحطط معدتك 🌚😹",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "🚶" or $text == "🚶🚶" or $text == "🚶🚶🚶" or $text == "🚶🚶🚶🚶" or $text == "🚶🚶🚶🚶🚶"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"شو فاتحيلك الكروب هنا للتتمشا فيه 🌚🌚😹",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "🌚" or $text == "🌚🌚" or $text == "🌚🌚🌚" or $text == "🌚🌚🌚🌚" or $text == "🌚🌚🌚🌚🌚"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"شبك قالب وجهك مثل الطسمة 😒🌝 ",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "روح" or $text == "رووح"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"لوين لا تخلينا اغلط عليك 🌚😹",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "تصبح ع خير" or $text == "تصبح ع خيرر" or $text == "تصبحو على خير" or $text == "تصبحو ع خير" or $text == "تصبح على خير" or $text == "تصبحو على خيرر" or $text == "تصبحو ع خيرر" or $text == "تصبح على خيرر"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"وانت/ي من اهل الخير نوم العوافي خاليه من الكوابيس وتشوف/ي انا 🙈❤️",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "بايش من وقت" or $text =="بايش من ساعة" or $text == "بايش من يوم"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"مدري 🌚😹",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "حبك"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"انت روحي 😘",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "اكرهك"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"بس انا ما بقدر ☺",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "ع راسي"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"ع راسك تاج الملوك يسلم راسك وراس الي خلفوك 😘",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "انا جيت" or $text =="انا اجيت"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"منووووور ايش اقول كمان 🌚😹",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "اني اجيت" or $text =="اني جيت"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"منوووووره حبي 😍",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "اسمع" or $text =="اسمعي"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"عم اشوف مو اسمع الحروف يا اخبل 🌚😹",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "تعرفه"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"ايه ايش تبون منه تحشون عليه 🌚",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "تعرفيها"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"ايه انا اعرفها هي تحبني 🙈❤️",
'reply_to_message_id'=>$message->message_id, 
]);
} if($text == "لا"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"قول/ي ايه وراضيك 😕💔",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "تشوف"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"ايه واضح مو اعمى 🌚💔",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "برد"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"اعطيك حطب من الي جمعته ما عندي حب 🌚😹",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "ضجه"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"مو بيدي تعال قلبي اهدي 🙊❤️",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "مجنون"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"بحبك 🙈❤️",
'reply_to_message_id'=>$message->message_id, 
]);
} if($text == "اخبل"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"هي اخلاقك حبيبي 🙈💔",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "ايش تقول"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"كلامي واضح احبك 🙈❤️",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "مافهمت"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"رح تتعب قلبي افهمك 😕😹",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "ايش تسوين"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"نسولف",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "هلا"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"✾ هـﮩـڵا ہبـﮩـک",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "مرحباء" or $text == "مرحبااء"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"مٌـﮩۚـرحـبّـﮩۘـتين",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "احمد" or $text == "عادل" or $text == "سعيد" or $text == "علي" or $text == "حسن" or $text == "ابوبكر" or $text == "منذر" or $text == "رمزي" or $text == "نبيل" or $text == "شعيب" or $text == "موسى" or $text == "عيسى" or $text == "ابراهيم" or $text == "محمد" or $text == "يحيى" or $text == "اسامه" or $text == "عبدالرحمن" or $text == "عبدالله" or $text == "مروان" or $text == "خالد" or $text == "ياسر" or $text == "فوزي"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"❃🌹عاشــ😍ــت الاســ🙈ـامي🌹❃  حـبـ💖ـي",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "مساءالخير"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"✾ مساء النور 🌝",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "سالخير"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"✾ سالنور 🌝",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "من وين"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"من سوو🇸 🇾رريـــــا 🌹💖",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "ادلب" or $text == "حمص" or $text == "حلب" or $text == "درعا" or $text == "اللاذقية" or $text == "دمشق" or $text == "الحسكة" or $text == "دير الزور" or $text == "الرقة" or $text == "ريف دمشق" or $text == "السويداء" or $text == "القنيطرة" or $text == "طرطوس" or $text == "حماة"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"✾ فديت ترابها 😘 هذي محافظة سوورية 💖",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "صنعاء"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"✾ صنعاء اليمن صنعاء اليمن فيها البنات الحاليه 😍",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "ابي"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"ربي يحفظه لكم ☺",
'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "طيب"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"شنو ساويت 😞",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "بكره"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"قول ان شاء الله ",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "جمعه مباركه" or $text == "جمعة مباركة"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"علينا وعليك بصحة والعافيه 😘",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "ايش اسمك" or $text == "شو اسمك"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"بوت ردود تبني لجروبك 😍",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "صباح الخير"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"صباح السعادة ☺✾",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "بكيفك"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"اوك 😼",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "بوسني" or $text == "بوسه"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"😍أمــ(❣💋❣)ـــﯙﯙﯙζ😍",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "الخاص"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"ممنــۅۅ؏ خـــ💒ــاص لتزحف حبي 😒",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "مات"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"الله يرحمه 😔💔",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "عشاني"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"ايه ❤",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "انته بتحبني" or $texr == "انت بتحبني"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"😹ولله ما ادري بس افكر😕",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "تكرهنا" or $texr == "تكرهني"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"موووو💀ووووت",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "اضحك"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"هہِهَہهَہهَہِہِهَہهَہهَہهَہهَہِ 😹😹",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "ابكي"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"اهئ اهئ اهئ اهئ 😿😿",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "فديتك"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"فداڪَ الـــڪَــون 😘",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "زعلت مني"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"لا ؏ــ﴿ُ😊﴾ـاديـﮯ",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "يدوم" or $texr == "يدووم" or $texr == "يدوووم"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"عًٌٍُـًٍَّـٍّْْـًًٌٍ﴿ًٍ😘ًٍ﴾ـٌٍُـٌٌٍَُـَّْـًًٍُزًٌٍّكٌٍُ",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "منور" or $texr == "منوور" or $texr == "منووور" or $texr == "منوووور" or $texr == "منوره" or $texr == "منووره"or $texr == "منوووره"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"نًُـَُِـ﴿ٰ💡﴾ًٌُِـِْْ🌟ـِـِوٍُرًٍُِك😍",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "تف"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"عــ😝ــلــيــگ",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "قول حبيبي"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"حْٰـٰبُّـmy lovaــّـْيُِْـٍِـّٰٓبـُي",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "فدوه"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"فــ ــّدًأَڳُ رّوّحــــيُ",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "قول احبك"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"احبــــگ 😘",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "قول احبيك"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"احبـــيگ 😘",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "الحمد لله ع كل حال" or $texr == "الحمد لله بخير" or $texr == "الحمدلله بخير" or $texr == "الحمدلله ع كل حال"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"..✿دِْۈۈ↝يِـًِ☝ـٍآٍرٍبُ↝ۈۈم✿",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "الحمدلله بخير"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"..✿دِْۈۈ↝يِـًِ☝ـٍآٍرٍبُ↝ۈۈم✿",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "وينكم" or $texr == "ليش مافي احد" or $texr == "ليش ساكتين وينكم"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"موجودين حياتي-_-♥",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "انا مين" or $texr == "اني مين"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"ما درينا ترى انا بوت ماتقول شخص",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "انيق"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"وسع الطريق هذا حبيبي 😍😘",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "انيق الالم"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"حبيبي 😍😘 ونا احبه مووووووت 🙈💋",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "صاحبك"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"صاحبي ما افرط فيه لو ذرة من شعره ",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "حبيبتك"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"ابي؏ الدنياء ؏ـشانها 😍💋 ",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "الحب"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"الحب ؏ـذاب فقش قلوب الشباب 😹😹",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "ادعي لي"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"الله يعطيك",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "حبيبتي"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"منو هذه تخوني ؏ـشانه 😔💔",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "يارب"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"يزوجني 😉😍",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "تتزوجني" or $texr == "تتزوجيني"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"ايه اصلن احـــبگ 😉🙈",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "مراتي" or $texr == "مرتي"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"ربي يحفظها لك ",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "زوجي"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"ربي يحفظه لك",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "مطور" or $text == "المطور"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"مـطور البـوت🍂 
:- @DS_DS

تـُواصـل المحضـوريـن 🛡
:- @SyriaAndroidBot

قـنـاة الـبـوتـ 📣🌍
:- @SyriaAndroid",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "قناة" or $text == "القناة"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"تفضل 🌹 هذي قـنـاة الـبـوتـ 📣🌍
:- @SyriaAndroid",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($new_member){ 
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'message_id'=>$message->message_id, 
'text'=>"<b>نووووورت/ي الكروب  ⚜️🌬</b> 
<b>حببيي ➖💎</b>  
<b>فضلا التزم بقوانين الكروب ❤️ 🔉</b>",
'parse_mode'=>"html", 
'reply_to_message_id'=>$message->message_id,
]); 
}
if($left){ 
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'message_id'=>$message->message_id, 
'text'=>"<b>غادر براحتك هو انت غادرت لانك مالقيت بنات تزحف عليهن😹😹 🙃💥</b>", 
'reply_to_message_id'=>$message->message_id,
'parse_mode'=>"html", 
]); 
}
if($text == "معلوماتي" or $text =="ايدي" or $text =="id" or $text =="/id"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'parse_mode'=>'MarkDown',
'disable_web_page_preview'=>true,
"text"=>" اســمــك 🔱◀️ : 
$name

يوزرك 🌐 ◀️  : 
[@$username](https://t.me/$username)

 ايديك ⚜️ ◀️ :
 $id, 
 
 [$name](https://t.me/$username)  ",
'message_id'=>$message->message_id,
'reply_markup'=>json_encode([
      'inline_keyboard'=>[
        [['text'=>'الـــمـــطــور 🔱🔰', 'url'=>"https://t.me/DS_DS"]],
]
])
]);
}
// @DS_DS    ابن الدولة الادلبية